function results=runTests
% Two schema cases per entry; executes only when the reader runs MATLAB.
% Contract tests are not reference-implementation equivalence tests.
root=fileparts(fileparts(mfilename('fullpath')));setupCookbook;
list=dir(fullfile(root,'algorithms','*.m'));results=struct([]);q=0;
for a=1:numel(list)
 name=erase(list(a).name,'.m');
 for v=1:2
  q=q+1;results(q).method=name;results(q).variant=v;results(q).pass=false;results(q).message='';
  try
   [fun,lb,ub,o,ref]=makeProblem(name,v);o.maxEval=3000;o.maxIter=50;
   [x,f,h]=feval(name,fun,lb,ub,o);
   assert(~isempty(x) && all(isfinite(f(:))),'No finite feasible result.');
   assert(all(all(x>=lb-1e-6 & x<=ub+1e-6)),'Bounds violated.');
   assert(h.totalEvaluations<=o.maxEval,'Evaluation cap exceeded.');
   if isfield(o,'multi') && o.multi
    assert(all(cbNondominated(f)),'Archive contains dominated points.');
   else
    assert(abs(fun(x)-f)<1e-7*(1+abs(f)),'Returned value mismatch.');
    if isfinite(ref.target),assert(f>=ref.target-1e-4,'Value below analytic lower bound: inspect feasibility or target.');end
    exact={'branch_bound','knapsack_dp','subset_sum_dp','held_karp','hungarian','dijkstra','bellman_ford','floyd_warshall','astar','edmonds_karp','simplex_lp','newton'};
    if any(strcmp(name,exact)),assert(abs(f-ref.target)<1e-6,'Exact small-case target mismatch.');end
    finite=h.best(isfinite(h.best));assert(all(diff(finite)<=1e-10),'Incumbent worsened.');
   end
   [x2,f2,h2]=feval(name,fun,lb,ub,o);
   assert(isequaln(x,x2) && isequaln(f,f2) && h.totalEvaluations==h2.totalEvaluations,'Same seed not reproducible.');
   results(q).pass=true;
  catch err,results(q).message=err.message;
  end
 end
end
save('test-results.mat','results');writetable(struct2table(results),'test-results.csv');
fprintf('%d / %d contract cases passed on %s\n',sum([results.pass]),numel(results),version);
end
