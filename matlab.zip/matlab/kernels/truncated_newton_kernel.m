function [x,extra]=truncated_newton_kernel(fun,lb,ub,o,mark)
% Newton-CG with negative-curvature detection and an outer Armijo search.
x=o.x0; n=numel(x);
for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o); f=fun(x);
    if norm(g,Inf)<o.tolerance, break; end
    d=zeros(n,1); residual=-g; p=residual;
    eta=min(0.5,sqrt(norm(g))); initial=norm(g);
    for j=1:n
        if isfield(o,'hessvec'), Hp=o.hessvec(x,p);
        else, H=cbHessian(fun,x,lb,ub,o); Hp=H*p; end
        curvature=p'*Hp;
        if curvature<=1e-14*(p'*p)
            if j==1, d=-g; end
            break;
        end
        rr=residual'*residual; step=rr/curvature;
        d=d+step*p; next=residual-step*Hp;
        if norm(next)<=eta*initial, break; end
        p=next+(next'*next/rr)*p; residual=next;
    end
    if g'*d>=0, d=-g; end
    [z,~]=cbLine(fun,x,f,g,d,lb,ub);
    change=norm(z-x,Inf); x=z; mark();
    if change<o.tolerance, break; end
end
extra=struct('outerIterations',k);
end
