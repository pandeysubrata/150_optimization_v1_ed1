function [x,extra]=epsilon_constraint_kernel(fun,lb,ub,o,mark)
% Epsilon-constraint method: explicit method kernel.
  % Two-objective teaching implementations. Columns are decision vectors.
  % All objective calls are archived by cbSolve; no scalar best is implied.
  n=numel(lb);
  N=o.popSize;
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(N,2);
  for i=1:N
    F(i,:)=fun(X(:,i));
  end
  assert(size(F,2)==2,'These recipes require two objectives.');
  ideal=min(F,[],1);
  for k=1:o.maxIter
    Y=zeros(n,N);
    G=zeros(N,2);
    for i=1:N
      ids=randperm(N,3);
      v=X(:,ids(1))+o.F*(X(:,ids(2))-X(:,ids(3)));
      mask=rand(n,1)<o.CR;
      mask(randi(n))=true;
      y=X(:,i);
      y(mask)=v(mask);
      Y(:,i)=min(ub,max(lb,y));
      G(i,:)=fun(Y(:,i));
      ideal=min(ideal,G(i,:));
    end
    assert(isfield(o,'epsilonLevels'),'Supply one objective-2 limit per subproblem.');
    for i=1:N
      e=o.epsilonLevels(i);
      old=max(0,F(i,2)-e);
      new=max(0,G(i,2)-e);
      if new<old || (new==old && G(i,1)<F(i,1))
        X(:,i)=Y(:,i);
        F(i,:)=G(i,:);
      end
    end
    mark();
  end
  x=X(:,1);
  extra=struct('population',X,'objectives',F,'scope','two-objective educational variant');
end
