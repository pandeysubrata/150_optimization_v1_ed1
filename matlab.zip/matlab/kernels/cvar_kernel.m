function [x,extra]=cvar_kernel(fun,lb,ub,o,mark)
% CVaR optimization: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  assert(isfield(o,'scenarios'),'Supply scenarios, one column per scenario.');
  S=o.scenarios;
  for k=1:o.maxIter
    z=x(1:end-1);
    t=x(end);
    loss=sum((z-S).^2,1);
    active=loss>t;
    g=[2*sum((z-S).*active,2)/(size(S,2)*(1-o.confidence)); 1-mean(active)/(1-o.confidence)];
    x=min(ub,max(lb,x-o.alpha/sqrt(k)*g));
    fun(x);
    mark();
  end
end
