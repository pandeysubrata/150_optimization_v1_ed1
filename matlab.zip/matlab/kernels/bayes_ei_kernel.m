function [x,extra]=bayes_ei_kernel(fun,lb,ub,o,mark)
% Gaussian-process expected improvement: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  X=[(x-lb)./span rand(n,max(3,n))];
  Y=zeros(size(X,2),1);
  for j=1:size(X,2)
    Y(j)=fun(lb+span.*X(:,j));
  end
  for k=1:o.maxIter
    pool=rand(n,300);
    D=squaredDistance(X,X);
    Dc=squaredDistance(X,pool);
    scale=max(std(Y),1e-12);
    normalized=(Y-mean(Y))/scale;
    K=exp(-D/(2*0.25^2))+1e-8*eye(numel(Y));
    R=chol(K,'lower');
    cross=exp(-Dc/(2*0.25^2));
    alpha=R'\(R\normalized);
    meanPrediction=cross'*alpha;
    v=R\cross;
    sd=sqrt(max(1e-12,1-sum(v.^2,1)))';
    improvement=min(normalized)-meanPrediction;
    z=improvement./sd;
    EI=improvement.*(0.5*erfc(-z/sqrt(2)))+sd.*exp(-z.^2/2)/sqrt(2*pi);
    [~,j]=max(EI);
    point=pool(:,j);
    X=[X point];
    Y=[Y;fun(lb+span.*point)];
    mark();
    %#ok<AGROW>
  end
  [~,j]=min(Y);
  x=lb+span.*X(:,j);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
function D=squaredDistance(X,Y)
  D=max(0,sum(X.^2,1)'+sum(Y.^2,1)-2*X'*Y);
end
