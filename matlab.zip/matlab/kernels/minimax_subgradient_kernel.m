function [x,extra]=minimax_subgradient_kernel(fun,lb,ub,o,mark)
% Robust minimax subgradient: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  assert(isfield(o,'scenarios'),'Supply scenarios, one column per scenario.');
  S=o.scenarios;
  for k=1:o.maxIter
    [~,j]=max(sum((x-S).^2,1));
    g=2*(x-S(:,j));
    x=min(ub,max(lb,x-o.alpha/sqrt(k)*g));
    fun(x);
    mark();
  end
end
