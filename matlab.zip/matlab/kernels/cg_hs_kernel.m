function [x,extra]=cg_hs_kernel(fun,lb,ub,o,mark)
% Hestenes-Stiefel nonlinear CG: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  oldg=[];
  oldd=[];
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    if ~isempty(oldg)
      delta=g-oldg;
      denominator=oldd'*delta;
      beta=0;
      if abs(denominator)>1e-14
        beta=(g'*delta)/denominator;
      end
      d=-g+beta*oldd;
    else
      d=-g;
    end
    if g'*d>=-1e-12*norm(g)*max(norm(d),eps)
      d=-g;
    end
    [z,fz]=cbLine(fun,x,f,g,d,lb,ub);
    oldg=g;
    oldd=d;
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
