function [x,extra]=knapsack_dp_kernel(fun,lb,ub,o,mark)
% Knapsack dynamic programming: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  w=p.weights(:);
  assert(all(w>0 & w==floor(w)));
  capacity=p.capacity;
  assert(capacity>=0 && capacity==floor(capacity));
  value=p.values(:);
  table=zeros(n+1,capacity+1);
  take=false(n,capacity+1);
  for i=1:n
    table(i+1,:)=table(i,:);
    for c=w(i):capacity
      proposal=table(i,c-w(i)+1)+value(i);
      if proposal>table(i+1,c+1)
        table(i+1,c+1)=proposal;
        take(i,c+1)=true;
      end
    end
    mark();
  end
  c=capacity;
  for i=n:-1:1
    if take(i,c+1)
      x(i)=1;
      c=c-w(i);
    end
  end
  extra.optimal=true;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
