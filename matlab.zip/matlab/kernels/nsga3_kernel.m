function [x,extra]=nsga3_kernel(fun,lb,ub,o,mark)
% NSGA-III: explicit method kernel.
name='nsga3';
  % Two-objective teaching implementations. Columns are decision vectors.
  % All objective calls are archived by cbSolve; no scalar best is implied.
  n=numel(lb);
  N=o.popSize;
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(N,2);
  for i=1:N
    F(i,:)=fun(X(:,i));
  end
  assert(size(F,2)==2,'These recipes require two objectives.');
  ideal=min(F,[],1);
  for k=1:o.maxIter
    Y=zeros(n,N);
    G=zeros(N,2);
    for i=1:N
      ids=randperm(N,3);
      v=X(:,ids(1))+o.F*(X(:,ids(2))-X(:,ids(3)));
      mask=rand(n,1)<o.CR;
      mask(randi(n))=true;
      y=X(:,i);
      y(mask)=v(mask);
      Y(:,i)=min(ub,max(lb,y));
      G(i,:)=fun(Y(:,i));
      ideal=min(ideal,G(i,:));
    end
    XX=[X Y];
    FF=[F;G];
    keep=cbParetoSelect(FF,N,name);
    X=XX(:,keep);
    F=FF(keep,:);
    mark();
  end
  x=X(:,1);
  extra=struct('population',X,'objectives',F,'scope','two-objective educational variant');
end
