function [x,extra]=hungarian_kernel(fun,lb,ub,o,mark)
% Hungarian assignment algorithm: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  % Rectangular assignment, rows <= columns. Potentials with dummy column.
  cost=p.cost;
  [nr,nc]=size(cost);
  assert(nr<=nc && nr==n && all(isfinite(cost(:))));
  u=zeros(nr+1,1);
  v=zeros(nc+1,1);
  matching=zeros(nc+1,1);
  way=zeros(nc+1,1);
  for i=1:nr
    matching(1)=i;
    j0=1;
    minv=Inf(nc+1,1);
    used=false(nc+1,1);
    while true
      used(j0)=true;
      i0=matching(j0);
      delta=Inf;
      j1=0;
      for j=2:nc+1
        if ~used(j)
          cur=cost(i0,j-1)-u(i0+1)-v(j);
          if cur<minv(j)
            minv(j)=cur;
            way(j)=j0;
          end
          if minv(j)<delta
            delta=minv(j);
            j1=j;
          end
        end
      end
      for j=1:nc+1
        if used(j)
          u(matching(j)+1)=u(matching(j)+1)+delta;
          v(j)=v(j)-delta;
        else
          minv(j)=minv(j)-delta;
        end
      end
      j0=j1;
      if matching(j0)==0
        break;
      end
    end
    while true
      j1=way(j0);
      matching(j0)=matching(j1);
      j0=j1;
      if j0==1
        break;
      end
    end
    mark();
  end
  for j=2:nc+1
    if matching(j)>0
      x(matching(j))=j-1;
    end
  end
  extra.optimal=true;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
