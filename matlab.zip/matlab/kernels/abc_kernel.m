function [bestX,extra]=abc_kernel(fun,lb,ub,o,mark)
% Artificial bee colony: explicit method kernel.
name='abc';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  trials=zeros(1,N);
  for k=1:o.maxIter
    [~,rank]=sort(F);
    for phase=1:2
      quality=1./(1+F-min(F));
      probability=quality/sum(quality);
      for q=1:N
        if phase==1
          j=q;
        else
          j=roulette(probability);
        end
        partner=randi(N-1);
        if partner>=j
          partner=partner+1;
        end
        d=randi(n);
        z=X(:,j);
        z(d)=z(d)+(2*rand-1)*(z(d)-X(d,partner));
        z=clip(z);
        fz=fun(z);
        if fz<F(j)
          X(:,j)=z;
          F(j)=fz;
          trials(j)=0;
        else
          trials(j)=trials(j)+1;
        end
      end
    end
    for j=find(trials>n*N)
      X(:,j)=lb+span.*rand(n,1);
      F(j)=fun(X(:,j));
      trials(j)=0;
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
function j=roulette(p)
  u=rand;
  j=find(cumsum(p)>=u,1);
  if isempty(j)
    j=numel(p);
  end
end
