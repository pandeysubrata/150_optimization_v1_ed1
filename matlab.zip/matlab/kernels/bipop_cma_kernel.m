function [x,extra]=bipop_cma_kernel(fun,lb,ub,o,mark)
% BIPOP-CMA-ES: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  n=numel(lb);
  N=o.popSize;
  x=o.x0;
  extra=struct();
  best=Inf;
  used=0;
  for r=1:4
    q=o;
    q.x0=lb+(ub-lb).*rand(n,1);
    if mod(r,2)==0
      q.popSize=max(6,round(N*2^((r-1)*rand/2)));
      q.sigma=.15*10^(-2*rand);
    else
      q.popSize=N*2^floor((r-1)/2);
    end
    q.maxIter=max(2,floor(o.maxIter/4));
    [y,~]=cbCMA(fun,lb,ub,q,mark);
    fy=fun(y);
    used=used+1;
    if fy<best
      best=fy;
      x=y;
    end
  end
  extra.restarts=used;
  extra.scope='four-restart teaching schedule';
  return;
end
