function [x,extra]=admm_kernel(fun,lb,ub,o,mark)
% ADMM: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  % Lasso: 0.5*||A*x-b||^2+lambda*||x||_1.
  A=p.A;
  b=p.b(:);
  z=x;
  u=zeros(n,1);
  rho=o.rho;
  M=A'*A+rho*eye(n);
  for k=1:o.maxIter
    x=M\(A'*b+rho*(z-u));
    old=z;
    z=sign(x+u).*max(abs(x+u)-o.lambda/rho,0);
    u=u+x-z;
    fun(z);
    mark();
    if max(norm(x-z),rho*norm(z-old))<o.tolerance
      break;
    end
  end
  extra.primalResidual=norm(x-z);
  x=z;
  % Detailed dual/primal trace can be added.
  fun(x);
end
