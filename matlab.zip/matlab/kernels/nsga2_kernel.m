function [x,extra]=nsga2_kernel(fun,lb,ub,o,mark)
% NSGA-II: rank/crowding tournaments, bounded SBX, polynomial mutation.
N=o.popSize; n=numel(lb); X=lb+(ub-lb).*rand(n,N);
F=fun(X(:,1)); F=F(:)'; F=repmat(F,N,1);
for i=2:N, value=fun(X(:,i)); F(i,:)=value(:)'; end
for k=1:o.maxIter
    [~,rank,crowd]=cbParetoSelect(F,N,'nsga2');
    Y=zeros(n,N);
    for i=1:2:N
        a=tournament(rank,crowd); b=tournament(rank,crowd);
        [c,d]=cbSBX(X(:,a),X(:,b),lb,ub,20);
        Y(:,i)=cbPolynomialMutation(c,lb,ub,20,1/n);
        if i<N
            Y(:,i+1)=cbPolynomialMutation(d,lb,ub,20,1/n);
        end
    end
    G=zeros(size(F));
    for i=1:N, value=fun(Y(:,i)); G(i,:)=value(:)'; end
    combined=[F;G]; population=[X Y];
    keep=cbParetoSelect(combined,N,'nsga2');
    X=population(:,keep); F=combined(keep,:); mark();
end
x=X(:,1);
extra=struct('population',X,'objectives',F, ...
    'scope','NSGA-II with bounded SBX and polynomial mutation');
end
function j=tournament(rank,crowd)
a=randi(numel(rank)); b=randi(numel(rank)); j=a;
if rank(b)<rank(a) || (rank(b)==rank(a) && crowd(b)>crowd(a))
    j=b;
elseif rank(b)==rank(a) && crowd(b)==crowd(a) && rand<0.5
    j=b;
end
end
