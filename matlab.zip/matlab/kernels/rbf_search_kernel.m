function [x,extra]=rbf_search_kernel(fun,lb,ub,o,mark)
% Radial-basis surrogate search: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  X=[(x-lb)./span rand(n,max(3,n))];
  Y=zeros(size(X,2),1);
  for j=1:size(X,2)
    Y(j)=fun(lb+span.*X(:,j));
  end
  for k=1:o.maxIter
    pool=rand(n,300);
    D=squaredDistance(X,X);
    Dc=squaredDistance(X,pool);
    scale=max(std(Y),1e-12);
    normalized=(Y-mean(Y))/scale;
    P=[ones(size(X,2),1) X'];
    K=D.^1.5+1e-8*eye(numel(Y));
    coeff=[K P;P' zeros(n+1)]\[normalized;zeros(n+1,1)];
    prediction=[Dc.^1.5;ones(1,size(pool,2));pool]'*coeff;
    distance=sqrt(min(Dc,[],1))';
    w=0.2+0.7*mod(k,5)/4;
    value=w*normalize(prediction)-(1-w)*normalize(distance);
    [~,j]=min(value);
    point=pool(:,j);
    X=[X point];
    Y=[Y;fun(lb+span.*point)];
    mark();
    %#ok<AGROW>
  end
  [~,j]=min(Y);
  x=lb+span.*X(:,j);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
function D=squaredDistance(X,Y)
  D=max(0,sum(X.^2,1)'+sum(Y.^2,1)-2*X'*Y);
end
function z=normalize(x)
  z=(x-min(x))/max(1e-12,max(x)-min(x));
end
