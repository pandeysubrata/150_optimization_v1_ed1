function [x,extra]=gauss_newton_kernel(fun,lb,ub,o,mark)
% min 0.5*||r(x)||^2; use QR/backslash, never form inverse normal equations.
x=o.x0;
for k=1:o.maxIter
    residual=o.residual(x); J=o.jacobian(x);
    g=J'*residual; f=fun(x);
    if norm(g,Inf)<o.tolerance, break; end
    d=-(J\residual);
    if g'*d>=0, d=-g; end
    [z,~]=cbLine(fun,x,f,g,d,lb,ub);
    change=norm(z-x,Inf); x=z; mark();
    if change<o.tolerance, break; end
end
extra=struct('iterations',k,'scope','full-column-rank residual Jacobian');
end
