function [x,extra]=simplex_lp_kernel(fun,lb,ub,o,mark)
% Primal simplex for LP: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  % min c'*x subject to A*x<=b, x>=0, b>=0; slack basis is feasible.
  A=p.A;
  b=p.b(:);
  c=p.c(:);
  assert(all(b>=0));
  [m,d]=size(A);
  tableau=[A eye(m) b];
  cost=[c;zeros(m,1)];
  basis=d+(1:m);
  for k=1:o.maxIter
    reduced=cost'-cost(basis)'*tableau(:,1:end-1);
    enter=find(reduced<-o.tolerance,1);
    % Bland's smallest-index rule.
    if isempty(enter)
      break;
    end
    positive=find(tableau(:,enter)>o.tolerance);
    assert(~isempty(positive),'LP is unbounded in this entering direction.');
    ratios=tableau(positive,end)./tableau(positive,enter);
    ratio=min(ratios);
    tied=positive(abs(ratios-ratio)<1e-10);
    [~,j]=min(basis(tied));
    leave=tied(j);
    tableau(leave,:)=tableau(leave,:)/tableau(leave,enter);
    for i=1:m
      if i~=leave
        tableau(i,:)=tableau(i,:)-tableau(i,enter)*tableau(leave,:);
      end
    end
    basis(leave)=enter;
    z=zeros(d+m,1);
    z(basis)=tableau(:,end);
    x=z(1:d);
    fun(x);
    mark();
  end
  z=zeros(d+m,1);
  z(basis)=tableau(:,end);
  x=z(1:d);
  extra.basis=basis;
  fun(x);
end
