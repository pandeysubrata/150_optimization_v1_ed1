function [x,extra]=nesterov_kernel(fun,lb,ub,o,mark)
% Nesterov accelerated gradient: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
fun(x);
  n=numel(x);
  velocity=zeros(n,1);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    y=min(ub,max(lb,x+o.beta*velocity));
    gy=cbGradient(fun,y,lb,ub,o);
    z=min(ub,max(lb,y-o.alpha*gy));
fun(z);
    velocity=z-x;
    change=norm(z-x,Inf);
    x=z;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
