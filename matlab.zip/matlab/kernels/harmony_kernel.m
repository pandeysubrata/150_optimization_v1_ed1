function [bestX,extra]=harmony_kernel(fun,lb,ub,o,mark)
% Harmony search: explicit method kernel.
name='harmony';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    [~,rank]=sort(F);
    z=zeros(n,1);
    for d=1:n
      if rand<0.9
        z(d)=X(d,randi(N));
        if rand<0.3
          z(d)=z(d)+0.01*span(d)*randn;
        end
      else
        z(d)=lb(d)+span(d)*rand;
      end
    end
    z=clip(z);
    fz=fun(z);
    [worst,j]=max(F);
    if fz<worst
      X(:,j)=z;
      F(j)=fz;
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
