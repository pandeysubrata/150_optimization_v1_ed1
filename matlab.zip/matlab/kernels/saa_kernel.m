function [x,extra]=saa_kernel(fun,lb,ub,o,mark)
% Sample-average approximation: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  assert(isfield(o,'scenarios'),'Supply scenarios, one column per scenario.');
  S=o.scenarios;
  for k=1:o.maxIter
    g=2*(x-mean(S,2));
    x=min(ub,max(lb,x-o.alpha/sqrt(k)*g));
    fun(x);
    mark();
  end
end
