function [x,extra]=gradient_descent_kernel(fun,lb,ub,o,mark)
% Gradient descent: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    d=-g;
    if g'*d>=-1e-12*norm(g)*max(norm(d),eps)
      d=-g;
    end
    [z,fz]=cbLine(fun,x,f,g,d,lb,ub);
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
