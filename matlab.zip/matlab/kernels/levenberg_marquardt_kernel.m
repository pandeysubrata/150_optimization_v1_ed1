function [x,extra]=levenberg_marquardt_kernel(fun,lb,ub,o,mark)
% Levenberg-Marquardt: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  n=numel(x);
  mu=1e-2;
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    assert(isfield(o,'residual'),'LM requires options.residual.');
    r=o.residual(x);
    r=r(:);
    J=zeros(numel(r),n);
    if isfield(o,'jacobian')
      J=o.jacobian(x);
    else
      for j=1:n
        h=1e-6*max(1,abs(x(j)));
        a=x;
        b=x;
        a(j)=min(ub(j),x(j)+h);
        b(j)=max(lb(j),x(j)-h);
        J(:,j)=(o.residual(a)-o.residual(b))/(a(j)-b(j));
      end
    end
    d=-(J'*J+mu*eye(n))\(J'*r);
    z=min(ub,max(lb,x+d));
    fz=fun(z);
    if fz<f
      mu=max(1e-12,mu/3);
    else
      mu=mu*5;
      z=x;
      fz=f;
    end
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance && false
      extra.stop='small displacement';
      break;
    end
  end
end
