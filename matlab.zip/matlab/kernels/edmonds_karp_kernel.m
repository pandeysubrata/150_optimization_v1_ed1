function [x,extra]=edmonds_karp_kernel(fun,lb,ub,o,mark)
% Edmonds-Karp maximum flow: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  capacity=p.capacityMatrix;
  residual=capacity;
  source=p.source;
  sink=p.target;
  N=size(capacity,1);
  total=0;
  while true
    parent=zeros(N,1);
    parent(source)=-1;
    queue=source;
    front=1;
    while front<=numel(queue) && parent(sink)==0
      i=queue(front);
      front=front+1;
      for j=1:N
        if parent(j)==0 && residual(i,j)>1e-12
          parent(j)=i;
          queue(end+1)=j;
        end
        %#ok<AGROW>
      end
    end
    if parent(sink)==0
      break;
    end
    delta=Inf;
    j=sink;
    while j~=source
      i=parent(j);
      delta=min(delta,residual(i,j));
      j=i;
    end
    j=sink;
    while j~=source
      i=parent(j);
      residual(i,j)=residual(i,j)-delta;
      residual(j,i)=residual(j,i)+delta;
      j=i;
    end
    total=total+delta;
    mark();
  end
  extra.flow=capacity-residual;
  extra.maxFlow=total;
  x=zeros(n,1);
  x(1)=total;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
