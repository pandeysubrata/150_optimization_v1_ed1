function [x,extra]=proximal_gradient_kernel(fun,lb,ub,o,mark)
% Proximal gradient / ISTA: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');

  t=1;
  for k=1:o.maxIter
    old=x;
    g=cbGradient(fun,x,lb,ub,o);
    assert(isfield(o,'prox'),'Supply options.prox(z,step) and smooth gradient.');
    base=x;
    x=o.prox(base-o.alpha*g,o.alpha);
    x=min(ub,max(lb,x));
    tn=(1+sqrt(1+4*t^2))/2;
    t=tn;
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
