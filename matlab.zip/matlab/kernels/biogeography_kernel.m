function [bestX,extra]=biogeography_kernel(fun,lb,ub,o,mark)
% Biogeography-based optimization: explicit method kernel.
name='biogeography';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      position=find(rank==i);
      immigration=(position-1)/max(1,N-1);
      emigration=(N-(1:N))/max(1,N-1);
      probs=zeros(1,N);
      probs(rank)=emigration;
      probs=probs/sum(probs);
      for d=1:n
        if rand<immigration
          candidate(d)=old(d,roulette(probs));
        end
        if rand<0.02
          candidate(d)=lb(d)+span(d)*rand;
        end
      end
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=false;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
function j=roulette(p)
  u=rand;
  j=find(cumsum(p)>=u,1);
  if isempty(j)
    j=numel(p);
  end
end
