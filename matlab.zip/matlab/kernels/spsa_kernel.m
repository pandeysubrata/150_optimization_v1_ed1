function [x,extra]=spsa_kernel(fun,lb,ub,o,mark)
% Simultaneous perturbation stochastic approximation: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  extra=struct('stop','iteration budget');
  for k=1:o.maxIter
    a=o.alpha/(k+10)^0.602;
    c=0.1/k^0.101;
    delta=2*(rand(n,1)>0.5)-1;
    plus=clip(x+c*delta);
    minus=clip(x-c*delta);
    g=(fun(plus)-fun(minus))./(2*c*delta);
    x=clip(x-a*g);
    fun(x);
    mark();
  end
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
