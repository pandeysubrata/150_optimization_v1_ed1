function [x,extra]=dfp_kernel(fun,lb,ub,o,mark)
% Davidon-Fletcher-Powell: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  n=numel(x);
  Hinv=eye(n);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    d=-Hinv*g;
    if g'*d>=-1e-12*norm(g)*max(norm(d),eps)
      d=-g;
    end
    [z,fz]=cbLine(fun,x,f,g,d,lb,ub);
    s=z-x;
    y=cbGradient(fun,z,lb,ub,o)-g;
    sy=s'*y;
    if sy>1e-10*norm(s)*max(norm(y),eps)
      Hy=Hinv*y;
      Hinv=Hinv+(s*s')/sy-(Hy*Hy')/(y'*Hy);
    end
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
