function [x,extra]=powell_kernel(fun,lb,ub,o,mark)
% Powell direction-set method: explicit method kernel.
  n=numel(lb);
  x=o.x0;
  f=fun(x);
  extra=struct('stop','iteration budget');
  directions=eye(n);
  for k=1:o.maxIter
    start=x;
    startF=f;
    decrease=0;
    replace=1;
    for j=1:n
      old=f;
      [x,f]=lineMin(x,directions(:,j));
      if old-f>decrease
        decrease=old-f;
        replace=j;
      end
    end
    displacement=x-start;
    if norm(displacement)<o.tolerance
      break;
    end
    extrap=clip(x+displacement);
    ft=fun(extrap);
    if ft<startF && 2*(startF-2*f+ft)*(startF-f-decrease)^2<decrease*(startF-ft)^2
      [x,f]=lineMin(x,displacement);
      directions(:,replace)=directions(:,end);
      directions(:,end)=displacement;
    end
    mark();
  end
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
