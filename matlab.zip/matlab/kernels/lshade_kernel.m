function [x,extra]=lshade_kernel(fun,lb,ub,o,mark)
% L-SHADE: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  n=numel(lb);
  N=o.popSize;
  x=o.x0;
  extra=struct();
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(1,N);
  for i=1:N
    F(i)=fun(X(:,i));
  end
  archive=zeros(n,0);
  MF=.5*ones(1,6);
  MC=MF;
  pos=1;
  indivF=.5*ones(1,N);
  indivCR=.9*ones(1,N);
  success=ones(1,4);
  startN=N; evaluations=N;
  for k=1:o.maxIter
    [~,rank]=sort(F);
    oldX=X;
    oldF=F;
    sf=[];
    sc=[];
    gain=[];
    for i=1:N
      ids=randperm(N);
      ids(ids==i)=[];
      strategy=1;
      h=randi(6);
      ff=-1;
      while ff<=0
        ff=MF(h)+.1*tan(pi*(rand-.5));
      end
      ff=min(1,ff);
      cr=min(1,max(0,MC(h)+.1*randn));
      pbest=oldX(:,rank(randi(max(2,ceil(.2*N)))));
      pool=[oldX archive];
      candidates=setdiff(1:size(pool,2),[i ids(1)]);
      r2=candidates(randi(numel(candidates)));
      y=oldX(:,i)+ff*(pbest-oldX(:,i))+ff*(oldX(:,ids(1))-pool(:,r2));
      mask=rand(n,1)<cr;
      mask(randi(n))=true;
      y(~mask)=oldX(~mask,i);
      y=min(ub,max(lb,y));
      fy=fun(y); evaluations=evaluations+1;
      if fy<oldF(i)
        archive=[archive oldX(:,i)];
        X(:,i)=y;
        F(i)=fy;
        sf(end+1)=ff;
        sc(end+1)=cr;
        gain(end+1)=oldF(i)-fy;
        indivF(i)=ff;
        indivCR(i)=cr;
        success(strategy)=success(strategy)+1;
      end
    end
    if size(archive,2)>N
      archive=archive(:,randperm(size(archive,2),N));
    end
    if ~isempty(sf)
      w=gain/sum(gain);
      MF(pos)=sum(w.*sf.^2)/sum(w.*sf);
      if any(sc>0), MC(pos)=sum(w.*sc.^2)/sum(w.*sc);
      else, MC(pos)=0; end
      pos=mod(pos,6)+1;
    end
    newN=max(4,round(startN-(startN-4)*min(1,evaluations/o.maxEval)));
    [~,order]=sort(F);
    order=order(1:newN);
    X=X(:,order);
    F=F(order);
    indivF=indivF(order);
    indivCR=indivCR(order);
    N=newN;
    mark();
  end
  [~,i]=min(F);
  x=X(:,i);
  extra.memoryF=MF;
  extra.memoryCR=MC;
  extra.scope='budget-based linear population reduction; clipped-bound variant';
end
