function [x,extra]=kruskal_kernel(fun,lb,ub,o,mark)
% Kruskal minimum spanning tree: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  N=size(W,1);
  assert(norm(W-W','fro')<1e-10 || isequaln(W,W'));
  edges=[];
  list=[];
  for i=1:N
    for j=i+1:N
      if isfinite(W(i,j))
        list=[list;i j W(i,j)];
      end
    end
  end
  %#ok<AGROW>
  [~,order]=sort(list(:,3));
  group=1:N;
  for q=order'
    i=list(q,1);
    j=list(q,2);
    if group(i)~=group(j)
      old=group(j);
      group(group==old)=group(i);
      edges=[edges;i j];
    end
    %#ok<AGROW>
    if size(edges,1)==N-1
      break;
    end
  end
  assert(size(edges,1)==N-1,'Graph is disconnected.');
  extra.edges=edges;
  x=zeros(n,1);
  % Rooted parent representation of the selected tree.
  visited=false(N,1);
  visited(1)=true;
  for k=1:N
    for j=1:size(edges,1)
      a=edges(j,1);
      b=edges(j,2);
      if visited(a) && ~visited(b)
        x(b)=a;
        visited(b)=true;
      elseif visited(b) && ~visited(a)
        x(a)=b;
        visited(a)=true;
      end
    end
  end
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
