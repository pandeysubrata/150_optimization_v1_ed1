function [x,extra]=real_ga_kernel(fun,lb,ub,o,mark)
% Real-coded genetic algorithm: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=false;

  for j=1:N
    F(j)=fun(X(:,j));
  end
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    [~,elite]=min(F);
    children=X;
    CF=F;
    for j=1:N
      a=tournament(F);
      b=tournament(F);

      children(:,j)=z;
      CF(j)=fun(z);
    end
    [~,worst]=max(CF);
    if F(elite)<CF(worst)
      children(:,worst)=X(:,elite);
      CF(worst)=F(elite);
    end
    X=children;
    F=CF;
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
function j=tournament(F)
  ids=randi(numel(F),1,2);
  [~,q]=min(F(ids));
  j=ids(q);
end
