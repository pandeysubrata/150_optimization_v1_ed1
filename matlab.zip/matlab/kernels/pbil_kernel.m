function [x,extra]=pbil_kernel(fun,lb,ub,o,mark)
% Population-based incremental learning: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=true;
  if binary
    assert(all(lb==0 & ub==1),'Binary methods require 0/1 domains.');
    X=double(rand(n,N)<0.5);
  end
  for j=1:N
    F(j)=fun(X(:,j));
  end
  probability=0.5*ones(n,1);
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    X=double(rand(n,N)<probability);
    for j=1:N
      F(j)=fun(X(:,j));
    end
    [~,order]=sort(F);
    probability=0.9*probability+0.1*X(:,order(1));
    margin=1/max(10,n);
    probability=min(1-margin,max(margin,probability));
    if n==1
      probability=min(0.99,max(0.01,probability));
    end
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
