function [x,extra]=basin_hopping_kernel(fun,lb,ub,o,mark)
% Basin hopping: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  n=numel(lb);
  x=o.x0;
  extra=struct();
  fx=fun(x);
  for k=1:o.maxIter
    y=min(ub,max(lb,x+.2*(ub-lb).*randn(n,1)));
    for j=1:8
      fy=fun(y);
      g=cbGradient(fun,y,lb,ub,o);
      [y,fy]=cbLine(fun,y,fy,g,-g,lb,ub);
    end
    if fy<fx || rand<exp(min(0,(fx-fy)/max(o.alpha,eps)))
      x=y;
      fx=fy;
    end
    mark();
  end
  return;
end
