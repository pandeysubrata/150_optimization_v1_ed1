function [x,extra]=adamax_kernel(fun,lb,ub,o,mark)
% AdaMax: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  first=zeros(n,1);
  second=first;
  b1=0.9;
  b2=0.999;
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    first=b1*first+(1-b1)*g;
    second=max(b2*second,abs(g));
    change=o.alpha/(1-b1^k)*first./(second+o.epsilon);
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
