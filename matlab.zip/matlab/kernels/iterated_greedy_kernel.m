function [bestTour,extra]=iterated_greedy_kernel(fun,lb,ub,o,mark)
% Iterated greedy: explicit method kernel.
  % These local-search recipes use symmetric TSP tours, not arbitrary vectors.
  W=o.problem.graph;
  n=size(W,1);
  tour=(1:n)';
  current=fun(tour);
  best=current;
  bestTour=tour;
  temperature=max(1e-8,0.1*abs(current));
  threshold=temperature;
  for k=1:o.maxIter
    remove=randperm(n,max(1,ceil(n/4)));
    removed=tour(remove);
    z=tour;
    z(remove)=[];
    for city=removed'
      increase=Inf;
      location=1;
      for j=1:numel(z)
        next=z(mod(j,numel(z))+1);
        cost=W(z(j),city)+W(city,next)-W(z(j),next);
        if cost<increase
          increase=cost;
          location=j;
        end
      end
      z=[z(1:location);city;z(location+1:end)];
      %#ok<AGROW>
    end
    [z,fz]=improve(z,zeros(n));
    accept=fz<current;
    accept=accept || rand<exp(min(0,(current-fz)/max(temperature,realmin)));
    if accept
      tour=z;
      current=fz;
    end
    if fz<best
      best=fz;
      bestTour=z;
    end
    temperature=0.97*temperature;
    threshold=0.97*threshold;
    mark();
  end
  extra=struct('stop','iteration budget','specialization','symmetric TSP','bestTourCost',best);
  function [z,value]=improve(z,penalty)
    value=fun(z);
    augmented=value+edgePenalty(z,penalty);
    for sweep=1:10
      changed=false;
      for a=2:n-1
        for b=a+1:n
          candidate=z;
          candidate(a:b)=flipud(candidate(a:b));
          cost=fun(candidate);
          score=cost+edgePenalty(candidate,penalty);
          if score<augmented
            z=candidate;
            value=cost;
            augmented=score;
            changed=true;
          end
        end
      end
      if ~changed
        break;
      end
    end
  end
end
function value=edgePenalty(tour,P)
  value=0;
  n=numel(tour);
  for k=1:n
    value=value+P(tour(k),tour(mod(k,n)+1));
  end
end
