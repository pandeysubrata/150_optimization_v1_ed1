function [x,extra]=jde_kernel(fun,lb,ub,o,mark)
% jDE: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  n=numel(lb);
  N=o.popSize;
  x=o.x0;
  extra=struct();
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(1,N);
  for i=1:N
    F(i)=fun(X(:,i));
  end
  archive=zeros(n,0);
  MF=.5*ones(1,6);
  MC=MF;
  pos=1;
  indivF=.5*ones(1,N);
  indivCR=.9*ones(1,N);
  success=ones(1,4);
  for k=1:o.maxIter
    [~,rank]=sort(F);
    oldX=X;
    oldF=F;
    sf=[];
    sc=[];
    gain=[];
    for i=1:N
      ids=randperm(N);
      ids(ids==i)=[];
      strategy=1;
      ff=indivF(i);
      cr=indivCR(i);
      if rand<.1
        ff=.1+.9*rand;
      end
      if rand<.1
        cr=rand;
      end
      y=oldX(:,ids(1))+ff*(oldX(:,ids(2))-oldX(:,ids(3)));
      mask=rand(n,1)<cr;
      mask(randi(n))=true;
      y(~mask)=oldX(~mask,i);
      y=min(ub,max(lb,y));
      fy=fun(y);
      if fy<oldF(i)
        archive=[archive oldX(:,i)];
        X(:,i)=y;
        F(i)=fy;
        sf(end+1)=ff;
        sc(end+1)=cr;
        gain(end+1)=oldF(i)-fy;
        indivF(i)=ff;
        indivCR(i)=cr;
        success(strategy)=success(strategy)+1;
      end
    end
    if size(archive,2)>N
      archive=archive(:,randperm(size(archive,2),N));
    end
    if ~isempty(sf)
      w=gain/sum(gain);
      MF(pos)=sum(w.*sf.^2)/sum(w.*sf);
      MC(pos)=sum(w.*sc);
      pos=mod(pos,6)+1;
    end
    mark();
  end
  [~,i]=min(F);
  x=X(:,i);
  extra.memoryF=MF;
  extra.memoryCR=MC;
  extra.scope='educational variant: iteration-based population reduction and simplified adaptation';
end
