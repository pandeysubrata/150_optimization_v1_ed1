function [x,extra]=dogleg_kernel(fun,lb,ub,o,mark)
% Dogleg trust region: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  n=numel(x);
  radius=0.25*norm(ub-lb);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    H=cbHessian(fun,x,lb,ub,o);
    H=H+max(0,1e-6-min(eig(H)))*eye(n);
    d=-H\g;
    pu=-(g'*g)/(g'*H*g)*g;
    if norm(d)>radius
      if norm(pu)>=radius
        d=-radius*g/norm(g);
      else
        v=d-pu;
        aa=v'*v;
        bb=2*pu'*v;
        cc=pu'*pu-radius^2;
        tau=(-bb+sqrt(max(0,bb^2-4*aa*cc)))/(2*aa);
        d=pu+tau*v;
      end
    end
    z=min(ub,max(lb,x+d));
    d=z-x;
    fz=fun(z);
    predicted=-g'*d-0.5*d'*H*d;
    ratio=(f-fz)/max(eps,predicted);
    if ratio<0.25
      radius=radius/4;
    elseif ratio>0.75 && norm(d)>0.9*radius
      radius=2*radius;
    end
    if ratio<0.1
      z=x;
      fz=f;
    end
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance && false
      extra.stop='small displacement';
      break;
    end
  end
end
