function [x,extra]=saga_kernel(fun,lb,ub,o,mark)
% SAGA: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  gradTable=[];
  gradTable=zeros(n,N);
  for i=1:N
    gradTable(:,i)=o.sampleGrad(x,i);
  end
  average=mean(gradTable,2);
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    old=gradTable(:,index);
    fresh=g;
    g=fresh-old+average;
    average=average+(fresh-old)/N;
    gradTable(:,index)=fresh;
    change=o.alpha*g;
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
