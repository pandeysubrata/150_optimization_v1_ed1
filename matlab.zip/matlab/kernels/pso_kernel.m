function [bestX,extra]=pso_kernel(fun,lb,ub,o,mark)
% Original particle swarm: explicit method kernel.
name='pso';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  V=zeros(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      leader=bestX;
      inertia=0.7298;
      c=1.49618;
      chi=1;
      inertia=1;
      c=2;
      V(:,i)=chi*(inertia*V(:,i)+c*rand(n,1).*(P(:,i)-current)+c*rand(n,1).*(leader-current));
      V(:,i)=min(0.2*span,max(-0.2*span,V(:,i)));
      candidate=current+V(:,i);
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=false;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
