function [x,extra]=sqp_kernel(fun,lb,ub,o,mark)
% Equality-constrained SQP: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');

  assert(isfield(o,'equalities') && isfield(o,'constraintJac'),'Equality callbacks required.');
  c=o.equalities(x);
  rho=o.rho;
  for k=1:o.maxIter
    c=o.equalities(x);
    J=o.constraintJac(x);
    g=cbGradient(fun,x,lb,ub,o);
    H=cbHessian(fun,x,lb,ub,o);
    H=H+max(0,1e-6-min(eig(H)))*eye(n);
    delta=[H J';J zeros(numel(c))]\[-g;-c];
    d=delta(1:n);
    penalty=max(10,2*norm(delta(n+1:end),Inf));
    old=fun(x)+penalty*norm(c,1);
    step=1;
    for trial=1:30
      z=min(ub,max(lb,x+step*d));
      value=fun(z)+penalty*norm(o.equalities(z),1);
      if value<old
        break;
      end
      step=step/2;
    end
    x=z;
    fun(x);
    mark();
    if norm(o.equalities(x),Inf)<o.tolerance && k>5
      break;
    end
  end
  fun(x);
end
