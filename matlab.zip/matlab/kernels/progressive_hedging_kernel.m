function [x,extra]=progressive_hedging_kernel(fun,lb,ub,o,mark)
% Progressive hedging: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  % Equal-weight local costs 0.5*||x-a_i||^2; exact proximal subproblems.
  A=o.centers;
  M=size(A,2);
  U=zeros(size(A));
  Z=repmat(x,1,M);
  for k=1:o.maxIter
    old=x;
    Z=(A+o.rho*x-U)/(1+o.rho);
    x=mean(Z,2);
    U=U+o.rho*(Z-x);
    x=min(ub,max(lb,x));
    fun(x);
    mark();
    if norm(Z-x,'fro')<o.tolerance && norm(x-old)<o.tolerance
      break;
    end
  end
  extra.consensusResidual=norm(Z-x,'fro');
  extra.localDecisions=Z;
end
