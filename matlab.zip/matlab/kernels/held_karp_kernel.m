function [x,extra]=held_karp_kernel(fun,lb,ub,o,mark)
% Held-Karp TSP dynamic programming: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  N=size(W,1);
  assert(N<=18,'Teaching subset DP is limited to 18 cities.');
  count=2^(N-1);
  D=Inf(count,N);
  previous=zeros(count,N);
  D(1,1)=0;
  for mask=0:count-1
    for j=1:N
      if ~isfinite(D(mask+1,j))
        continue;
      end
      for q=2:N
        if ~bitget(mask,q-1)
          next=bitset(mask,q-1);
          trial=D(mask+1,j)+W(j,q);
          if trial<D(next+1,q)
            D(next+1,q)=trial;
            previous(next+1,q)=j;
          end
        end
      end
    end
  end
  [~,last]=min(D(end,2:end)+W(2:end,1)');
  last=last+1;
  x=zeros(N,1);
  mask=count-1;
  for pos=N:-1:2
    x(pos)=last;
    prior=previous(mask+1,last);
    mask=bitset(mask,last-1,0);
    last=prior;
  end
  x(1)=1;
  extra.optimal=true;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
