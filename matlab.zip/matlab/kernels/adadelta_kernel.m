function [x,extra]=adadelta_kernel(fun,lb,ub,o,mark)
% AdaDelta: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  first=zeros(n,1);
  second=first;
  updates=first;
  decay=0.95;
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    second=decay*second+(1-decay)*g.^2;
    change=sqrt(updates+o.epsilon)./sqrt(second+o.epsilon).*g;
    updates=decay*updates+(1-decay)*change.^2;
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
