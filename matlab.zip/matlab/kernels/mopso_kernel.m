function [x,extra]=mopso_kernel(fun,lb,ub,o,mark)
% Multi-objective PSO: explicit method kernel.
  % Two-objective teaching implementations. Columns are decision vectors.
  % All objective calls are archived by cbSolve; no scalar best is implied.
  n=numel(lb);
  N=o.popSize;
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(N,2);
  for i=1:N
    F(i,:)=fun(X(:,i));
  end
  assert(size(F,2)==2,'These recipes require two objectives.');
  V=zeros(n,N);
  personal=X;
  PF=F;
  for k=1:o.maxIter
    keep=cbNondominated(F);
    leaders=X(:,keep);
    for i=1:N
      lead=leaders(:,randi(size(leaders,2)));
      V(:,i)=.5*V(:,i)+1.5*rand(n,1).*(personal(:,i)-X(:,i))+1.5*rand(n,1).*(lead-X(:,i));
      V(:,i)=min(.2*(ub-lb),max(-.2*(ub-lb),V(:,i)));
      X(:,i)=min(ub,max(lb,X(:,i)+V(:,i)));
      F(i,:)=fun(X(:,i));
      if all(F(i,:)<=PF(i,:)) || (~all(PF(i,:)<=F(i,:)) && rand<.5)
        personal(:,i)=X(:,i);
        PF(i,:)=F(i,:);
      end
    end
    mark();
  end
  x=X(:,1);
  extra=struct('population',X,'objectives',F,'scope','two-objective educational variant');
end
