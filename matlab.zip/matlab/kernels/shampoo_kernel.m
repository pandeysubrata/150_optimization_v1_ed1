function [x,extra]=shampoo_kernel(fun,lb,ub,o,mark)
% Two-mode matrix Shampoo; eigendecompositions recomputed each step.
x=o.x0; shape=o.matrixShape; regularizer=1e-4;
L=regularizer*eye(shape(1)); R=regularizer*eye(shape(2));
for k=1:o.maxIter
    G=reshape(o.sampleGrad(x,randi(o.numSamples)),shape);
    L=L+G*G'; R=R+G'*G;
    left=inverseFourthRoot(L); right=inverseFourthRoot(R);
    U=left*G*right;
    x=x-o.alpha*U(:); x=min(ub,max(lb,x));
    fun(x); mark();
end
extra=struct('leftAccumulator',L,'rightAccumulator',R);
end
function B=inverseFourthRoot(A)
[V,D]=eig((A+A')/2);
eigenvalues=max(diag(D),1e-12);
B=V*diag(eigenvalues.^(-0.25))*V';
end
