function [x,extra]=cobyla_kernel(fun,lb,ub,o,mark)
% COBYLA: explicit method kernel.
  n=numel(lb);
  x=o.x0;
  f=fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  mesh=0.1;
  extra.variant='Declared educational mesh or linear-model variant';
  for k=1:o.maxIter
    old=f;
    directions=[eye(n) -eye(n)];
    % Affine interpolation on n+1 points, sampled trust-region LP candidates.
    samples=repmat(x,1,n+1);
    values=zeros(n+1,1);
    values(1)=f;
    for j=1:n
      samples(:,j+1)=clip(x+mesh*span(j)*eyeColumn(j));
      if norm(samples(:,j+1)-x)<eps
        samples(:,j+1)=clip(x-mesh*span(j)*eyeColumn(j));
      end
      values(j+1)=fun(samples(:,j+1));
    end
    geometry=[ones(n+1,1) (samples-x)'];
    coeff=geometry\values;
    candidates=[zeros(n,1) mesh*(span.*directions) mesh*(span.*randn(n,100))];
    candidates=candidates./max(1,sqrt(sum((candidates./span).^2,1))/mesh);
    predicted=coeff(1)+coeff(2:end)'*candidates;
    if isfield(o,'inequalities')
      constraints=[];
      for j=1:n+1
        constraints(j,:)=o.inequalities(samples(:,j))';
      end
      %#ok<AGROW>
      linear=geometry\constraints;
      predicted=predicted+100*sum(max(0,linear(1,:)'+linear(2:end,:)'*candidates),1);
    end
    [~,j]=min(predicted);
    z=clip(x+candidates(:,j));
    fz=fun(z);
    accept=fz<f;
    if isfield(o,'inequalities')
      accept=fz+100*sum(max(0,o.inequalities(z)))<f+100*sum(max(0,o.inequalities(x)));
    end
    if accept
      x=z;
      f=fz;
    end
    if f<old
      mesh=min(0.5,1.2*mesh);
    else
      mesh=mesh/2;
    end
    mark();
    if mesh*max(span)<o.tolerance
      break;
    end
  end
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
