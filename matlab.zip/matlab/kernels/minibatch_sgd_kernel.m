function [x,extra]=minibatch_sgd_kernel(fun,lb,ub,o,mark)
% Mini-batch SGD: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    g=zeros(n,1);
    for j=1:o.batchSize
      g=g+o.sampleGrad(x,randi(N))/o.batchSize;
    end
    change=o.alpha*g;
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
