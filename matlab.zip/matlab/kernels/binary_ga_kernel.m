function [x,extra]=binary_ga_kernel(fun,lb,ub,o,mark)
% Binary genetic algorithm: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=true;
  if binary
    assert(all(lb==0 & ub==1),'Binary methods require 0/1 domains.');
    X=double(rand(n,N)<0.5);
  end
  for j=1:N
    F(j)=fun(X(:,j));
  end
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    [~,elite]=min(F);
    children=X;
    CF=F;
    for j=1:N
      a=tournament(F);
      b=tournament(F);
      if binary
        mask=rand(n,1)<0.5;
        z=X(:,a);
        z(mask)=X(mask,b);
        flip=rand(n,1)<1/n;
        z(flip)=1-z(flip);
      else
        % Simulated binary crossover (eta=15), followed by Gaussian mutation.
        u=rand(n,1);
        beta=zeros(n,1);
        low=u<=0.5;
        beta(low)=(2*u(low)).^(1/16);
        beta(~low)=(1./(2*(1-u(~low)))).^(1/16);
        z=0.5*((1+beta).*X(:,a)+(1-beta).*X(:,b));
        mutation=rand(n,1)<1/n;
        z=z+mutation.*(0.05*span.*randn(n,1));
        z=min(ub,max(lb,z));
      end
      children(:,j)=z;
      CF(j)=fun(z);
    end
    [~,worst]=max(CF);
    if F(elite)<CF(worst)
      children(:,worst)=X(:,elite);
      CF(worst)=F(elite);
    end
    X=children;
    F=CF;
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
function j=tournament(F)
  ids=randi(numel(F),1,2);
  [~,q]=min(F(ids));
  j=ids(q);
end
