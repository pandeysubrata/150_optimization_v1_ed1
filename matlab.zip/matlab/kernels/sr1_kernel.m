function [x,extra]=sr1_kernel(fun,lb,ub,o,mark)
% Symmetric rank-one quasi-Newton: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  n=numel(x);
  Hinv=eye(n);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    d=-Hinv*g;
    if g'*d>=-1e-12*norm(g)*max(norm(d),eps)
      d=-g;
    end
    [z,fz]=cbLine(fun,x,f,g,d,lb,ub);
    s=z-x;
    y=cbGradient(fun,z,lb,ub,o)-g;
    v=s-Hinv*y;
    den=v'*y;
    if abs(den)>1e-8*norm(v)*norm(y)
      Hinv=Hinv+(v*v')/den;
    end
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
