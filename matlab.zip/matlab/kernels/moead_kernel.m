function [x,extra]=moead_kernel(fun,lb,ub,o,mark)
% MOEA/D: explicit method kernel.
  % Two-objective teaching implementations. Columns are decision vectors.
  % All objective calls are archived by cbSolve; no scalar best is implied.
  n=numel(lb);
  N=o.popSize;
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(N,2);
  for i=1:N
    F(i,:)=fun(X(:,i));
  end
  assert(size(F,2)==2,'These recipes require two objectives.');
  W=[linspace(0,1,N)' linspace(1,0,N)'];
  ideal=min(F,[],1);
  for k=1:o.maxIter
    Y=zeros(n,N);
    G=zeros(N,2);
    for i=1:N
      [~,near]=sort(sum((W-W(i,:)).^2,2));
      pool=near(1:min(N,10));
      ids=pool(randperm(numel(pool),3));
      v=X(:,ids(1))+o.F*(X(:,ids(2))-X(:,ids(3)));
      mask=rand(n,1)<o.CR;
      mask(randi(n))=true;
      y=X(:,i);
      y(mask)=v(mask);
      Y(:,i)=min(ub,max(lb,y));
      G(i,:)=fun(Y(:,i));
      ideal=min(ideal,G(i,:));
      for j=pool(:)'
        if max(max(W(j,:),1e-6).*abs(G(i,:)-ideal))<=max(max(W(j,:),1e-6).*abs(F(j,:)-ideal))
          X(:,j)=Y(:,i);
          F(j,:)=G(i,:);
        end
      end
    end
    mark();
  end
  x=X(:,1);
  extra=struct('population',X,'objectives',F,'scope','two-objective educational variant');
end
