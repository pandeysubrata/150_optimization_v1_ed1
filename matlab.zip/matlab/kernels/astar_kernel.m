function [x,extra]=astar_kernel(fun,lb,ub,o,mark)
% A-star search: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  source=p.source;
  N=size(W,1);
  assert(N==n);
  distance=Inf(N,1);
  distance(source)=0;
  parent=zeros(N,1);
  assert(all(W(isfinite(W))>=0),'Nonnegative edges required.');
  closed=false(N,1);
  heuristic=zeros(N,1);
  heuristic=p.heuristic(:);
  for k=1:max(N,o.maxIter)
    score=distance+heuristic;
    score(closed)=Inf;
    [best,i]=min(score);
    if ~isfinite(best)
      break;
    end
    closed(i)=true;
    if i==p.target
      break;
    end
    for j=1:N
      if distance(i)+W(i,j)<distance(j)
        distance(j)=distance(i)+W(i,j);
        parent(j)=i;
        closed(j)=false;
        % Reopen for inconsistent admissible h.
      end
    end
    mark();
  end
  x=parent;
  extra.distance=distance;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
