function [x,extra]=projected_gradient_kernel(fun,lb,ub,o,mark)
% Projected gradient: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');

  for k=1:o.maxIter
    old=x;
    g=cbGradient(fun,x,lb,ub,o);
    x=min(ub,max(lb,x-o.alpha*g));
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
