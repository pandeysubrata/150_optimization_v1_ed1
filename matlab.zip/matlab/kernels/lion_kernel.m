function [x,extra]=lion_kernel(fun,lb,ub,o,mark)
% Lion: sign update and a separate momentum-update coefficient.
x=o.x0; m=zeros(size(x)); b1=0.9; b2=0.99;
for k=1:o.maxIter
    g=o.sampleGrad(x,randi(o.numSamples));
    direction=sign(b1*m+(1-b1)*g);
    x=(1-o.alpha*o.lambda)*x-o.alpha*direction;
    x=min(ub,max(lb,x));
    m=b2*m+(1-b2)*g;
    fun(x); mark();
end
extra=struct('beta1',b1,'beta2',b2);
end
