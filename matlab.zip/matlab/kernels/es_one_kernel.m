function [x,extra]=es_one_kernel(fun,lb,ub,o,mark)
% One-plus-one evolution strategy: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=false;

  for j=1:N
    F(j)=fun(X(:,j));
  end
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    z=min(ub,max(lb,x+sigma.*randn(n,1)));
    fz=fun(z);
    success=fz<best;
    if success
      x=z;
      best=fz;
    end
    sigma=sigma*exp((double(success)-0.2)/sqrt(n+1));
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
