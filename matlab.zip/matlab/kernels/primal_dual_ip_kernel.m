function [x,extra]=primal_dual_ip_kernel(fun,lb,ub,o,mark)
% Primal-dual interior point: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  % min c'*x, A*x=b, x>=0; infeasible-start primal-dual Newton steps.
  A=p.A;
  b=p.b(:);
  c=p.c(:);
  m=size(A,1);
  x=max(1,o.x0);
  s=ones(n,1);
  y=zeros(m,1);
  for k=1:o.maxIter
    rp=A*x-b;
    rd=A'*y+s-c;
    mu=(x'*s)/n;
    if max([norm(rp,Inf),norm(rd,Inf),mu])<o.tolerance
      break;
    end
    target=0.1*mu;
    K=[zeros(n) A' eye(n);A zeros(m,m+n);diag(s) zeros(n,m) diag(x)];
    delta=K\[-rd;-rp;target*ones(n,1)-x.*s];
    dx=delta(1:n);
    dy=delta(n+1:n+m);
    ds=delta(n+m+1:end);
    ap=1;
    ad=1;
    if any(dx<0)
      ap=min(1,0.99*min(-x(dx<0)./dx(dx<0)));
    end
    if any(ds<0)
      ad=min(1,0.99*min(-s(ds<0)./ds(ds<0)));
    end
    x=x+ap*dx;
    y=y+ad*dy;
    s=s+ad*ds;
    fun(x);
    mark();
  end
  extra.primalResidual=norm(A*x-b,Inf);
  extra.dualResidual=norm(A'*y+s-c,Inf);
  extra.gap=x'*s;
  fun(x);
end
