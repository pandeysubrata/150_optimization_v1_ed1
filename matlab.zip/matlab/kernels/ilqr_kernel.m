function [u,extra]=ilqr_kernel(fun,lb,ub,o,mark)
% iLQR for quadratic stage/terminal costs and optional nonlinear dynamics.
% options.dynamics(x,u) overrides A*x+B*u; fun must score that same rollout.
H=o.horizon; nx=numel(o.initialState); nu=numel(lb)/H;
assert(nu==floor(nu),'Bounds must contain H control vectors.');
u=o.x0; mu=1e-6; value=fun(u); X=rollout(u,o,H,nu);
for iteration=1:o.maxIter
    Vx=2*o.Qf*X(:,end); Vxx=2*o.Qf;
    feed=zeros(nu,H); gain=zeros(nu,nx,H);
    for t=H:-1:1
        ids=(t-1)*nu+(1:nu); ut=u(ids); xt=X(:,t);
        [A,B]=jacobians(xt,ut,o);
        Qx=2*o.Q*xt+A'*Vx; Qu=2*o.R*ut+B'*Vx;
        Qxx=2*o.Q+A'*Vxx*A; Qux=B'*Vxx*A;
        Quu=2*o.R+B'*Vxx*B; Quu=(Quu+Quu')/2;
        shift=max(mu,mu-min(eig(Quu)));
        regular=Quu+shift*eye(nu);
        feed(:,t)=-regular\Qu; gain(:,:,t)=-regular\Qux;
        K=gain(:,:,t); k=feed(:,t);
        Vx=Qx+K'*Quu*k+K'*Qu+Qux'*k;
        Vxx=Qxx+K'*Quu*K+K'*Qux+Qux'*K;
        Vxx=(Vxx+Vxx')/2;
    end
    accepted=false;
    for alpha=2.^(-(0:12))
        trial=zeros(size(u)); Y=zeros(nx,H+1);
        Y(:,1)=o.initialState;
        for t=1:H
            ids=(t-1)*nu+(1:nu);
            control=u(ids)+alpha*feed(:,t)+ ...
                gain(:,:,t)*(Y(:,t)-X(:,t));
            trial(ids)=min(ub(ids),max(lb(ids),control));
            Y(:,t+1)=dynamics(Y(:,t),trial(ids),o);
        end
        trialValue=fun(trial);
        if trialValue<value
            change=norm(trial-u,Inf); u=trial; X=Y;
            value=trialValue; accepted=true; break;
        end
    end
    mark();
    if accepted
        mu=max(1e-9,mu/3);
        if change<o.tolerance, break; end
    else
        mu=10*mu;
        if mu>1e10 || norm(feed(:),Inf)<o.tolerance, break; end
    end
end
extra=struct('path',X,'firstMove',u(1:nu), ...
    'scope','iLQR with quadratic costs and clipped rollout controls');
end
function X=rollout(u,o,H,nu)
X=zeros(numel(o.initialState),H+1); X(:,1)=o.initialState;
for t=1:H
    ids=(t-1)*nu+(1:nu); X(:,t+1)=dynamics(X(:,t),u(ids),o);
end
end
function y=dynamics(x,u,o)
if isfield(o,'dynamics'), y=o.dynamics(x,u);
else, y=o.A*x+o.B*u; end
end
function [A,B]=jacobians(x,u,o)
if ~isfield(o,'dynamics'), A=o.A; B=o.B; return; end
nx=numel(x); nu=numel(u); A=zeros(nx); B=zeros(nx,nu);
for j=1:nx
    h=1e-5*(1+abs(x(j))); e=zeros(nx,1); e(j)=h;
    A(:,j)=(dynamics(x+e,u,o)-dynamics(x-e,u,o))/(2*h);
end
for j=1:nu
    h=1e-5*(1+abs(u(j))); e=zeros(nu,1); e(j)=h;
    B(:,j)=(dynamics(x,u+e,o)-dynamics(x,u-e,o))/(2*h);
end
end
