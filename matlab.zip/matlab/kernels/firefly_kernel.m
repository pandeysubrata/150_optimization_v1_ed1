function [bestX,extra]=firefly_kernel(fun,lb,ub,o,mark)
% Firefly algorithm: explicit method kernel.
name='firefly';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    for i=1:N
      z=X(:,i);
      for j=1:N
        if oldF(j)<oldF(i)
          distance=sum(((z-old(:,j))./span).^2);
          attraction=exp(-distance);
          z=clip(z+attraction*(old(:,j)-z)+0.1*(0.97^k)*span.*randn(n,1));
        end
      end
      X(:,i)=z;
      F(i)=fun(z);
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
