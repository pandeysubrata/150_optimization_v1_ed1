function [x,extra]=log_barrier_kernel(fun,lb,ub,o,mark)
% Logarithmic barrier: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  A=p.A;
  b=p.b(:);
  assert(all(b-A*x>0),'Strictly feasible x0 required.');
  mu=1;
  for k=1:o.maxIter
    slack=b-A*x;
    g=cbGradient(fun,x,lb,ub,o)+mu*A'*(1./slack);
    H=cbHessian(fun,x,lb,ub,o)+mu*A'*diag(1./slack.^2)*A;
    H=H+max(0,1e-8-min(eig(H)))*eye(n);
    d=-H\g;
    step=1;
    old=fun(x)-mu*sum(log(slack));
    for j=1:40
      z=min(ub,max(lb,x+step*d));
      sz=b-A*z;
      if all(sz>0) && fun(z)-mu*sum(log(sz))<=old+1e-4*step*g'*d
        break;
      end
      step=step/2;
    end
    x=z;
    fun(x);
    mark();
    if mod(k,10)==0
      mu=mu/5;
    end
  end
  extra.barrier=mu;
  fun(x);
end
