function [x,extra]=two_opt_kernel(fun,lb,ub,o,mark)
% 2-opt tour improvement: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  N=size(W,1);
  x=(1:N)';
  f=fun(x);
  for k=1:o.maxIter
    improved=false;
    for i=2:N-1
      for j=i+1:N
        z=x;
        z(i:j)=flipud(z(i:j));
        fz=fun(z);
        if fz<f
          x=z;
          f=fz;
          improved=true;
        end
      end
    end
    mark();
    if ~improved
      break;
    end
  end
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
