function [x,extra]=mirror_descent_kernel(fun,lb,ub,o,mark)
% Entropic mirror descent: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');

  x=max(x,1e-12);
  x=x/sum(x);
  for k=1:o.maxIter
    old=x;
    g=cbGradient(fun,x,lb,ub,o);
    logits=log(max(x,realmin))-o.alpha*g;
    logits=logits-max(logits);
    x=exp(logits);
    x=x/sum(x);
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
