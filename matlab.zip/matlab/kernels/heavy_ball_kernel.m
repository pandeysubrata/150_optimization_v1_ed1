function [x,extra]=heavy_ball_kernel(fun,lb,ub,o,mark)
% Heavy-ball momentum: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
fun(x);
  n=numel(x);
  velocity=zeros(n,1);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    velocity=o.beta*velocity-o.alpha*g;
    d=velocity;
    z=min(ub,max(lb,x+d));
fun(z);
    change=norm(z-x,Inf);
    x=z;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
