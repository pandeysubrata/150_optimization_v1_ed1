function [x,extra]=de_current_best_kernel(fun,lb,ub,o,mark)
% DE/current-to-best/1/bin: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=false;

  for j=1:N
    F(j)=fun(X(:,j));
  end
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    % Canonical differential mutation strategies; synchronous generation.
    old=X;
    oldF=F;
    [~,bestIndex]=min(oldF);
    for j=1:N
      ids=setdiff(1:N,j);
      ids=ids(randperm(numel(ids)));
      r=ids(1:5);
      mutant=old(:,j)+o.F*(old(:,bestIndex)-old(:,j)+old(:,r(1))-old(:,r(2)));
      mutant=min(ub,max(lb,mutant));
      mask=rand(n,1)<o.CR;
      mask(randi(n))=true;
      z=old(:,j);
      z(mask)=mutant(mask);
      fz=fun(z);
      if fz<=oldF(j)
        X(:,j)=z;
        F(j)=fz;
      end
    end
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
