function [x,extra]=away_frank_wolfe_kernel(fun,lb,ub,o,mark)
% Away-step Frank-Wolfe: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');

  x=max(x,1e-12);
  x=x/sum(x);
  for k=1:o.maxIter
    old=x;
    g=cbGradient(fun,x,lb,ub,o);
    [~,j]=min(g);
    vertex=zeros(n,1);
    vertex(j)=1;
    d=vertex-x;
    maxStep=1;
    active=find(x>1e-12);
    [~,q]=max(g(active));
    jaway=active(q);
    away=zeros(n,1);
    away(jaway)=1;
    da=x-away;
    if g'*da<g'*d && x(jaway)<1-1e-12
      d=da;
      maxStep=x(jaway)/(1-x(jaway));
    end
    step=min(maxStep,2/(k+2));
    f=fun(x);
    for j=1:30
      candidate=x+step*d;
      if fun(candidate)<=f+1e-4*step*g'*d
        break;
      end
      step=step/2;
    end
    x=x+step*d;
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
