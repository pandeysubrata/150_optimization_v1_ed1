function [x,extra]=golden_section_kernel(fun,lb,ub,o,mark)
% Golden-section search: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  extra=struct('stop','iteration budget');
  assert(n==1,'Scalar method requires one variable.');
  [x,~]=cbScalar(fun,lb,ub,o.tolerance,o.maxIter,false);
  mark();
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
