function [x,extra]=mads_kernel(fun,lb,ub,o,mark)
% Mesh adaptive direct search: explicit method kernel.
  n=numel(lb);
  x=o.x0;
  f=fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  mesh=0.1;
  extra.variant='Declared educational mesh or linear-model variant';
  for k=1:o.maxIter
    old=f;
    B=round(randn(n)/max(mesh,1e-3));
    if rank(B)<n
      B=eye(n);
    end
    directions=[B -B];
    directions=directions./max(1,sqrt(sum(directions.^2,1)));
    for j=1:size(directions,2)
      z=clip(x+mesh*(span.*directions(:,j)));
      fz=fun(z);
      if fz<f
        x=z;
        f=fz;
        break;
      end
    end
    if f<old
      mesh=min(0.5,1.2*mesh);
    else
      mesh=mesh/2;
    end
    mark();
    if mesh*max(span)<o.tolerance
      break;
    end
  end
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
