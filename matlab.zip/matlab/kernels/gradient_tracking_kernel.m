function [x,extra]=gradient_tracking_kernel(fun,lb,ub,o,mark)
% Distributed gradient tracking: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  A=o.centers;
  W=o.mixing;
  M=size(A,2);
  assert(all(size(W)==[M M]) && norm(W-W')<1e-10 && norm(sum(W,1)-1)<1e-10);
  Z=repmat(x,1,M);
  G=Z-A;
  Y=G;
  for k=1:o.maxIter
    next=Z*W-o.alpha*Y;
    newG=next-A;
    Y=Y*W+newG-G;
    Z=next;
    G=newG;
    x=min(ub,max(lb,mean(Z,2)));
    fun(x);
    mark();
  end
  extra.consensusResidual=norm(Z-mean(Z,2),'fro');
  extra.localDecisions=Z;
end
