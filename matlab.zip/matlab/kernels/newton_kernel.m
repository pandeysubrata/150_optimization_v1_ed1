function [x,extra]=newton_kernel(fun,lb,ub,o,mark)
% Newton's method: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
fun(x);
  n=numel(x);
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    H=cbHessian(fun,x,lb,ub,o);
    if rcond(H)<1e-12
      H=H+1e-6*eye(n);
    end
    d=-H\g;
    z=min(ub,max(lb,x+d));
fun(z);
    change=norm(z-x,Inf);
    x=z;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
