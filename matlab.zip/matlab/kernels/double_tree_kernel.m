function [x,extra]=double_tree_kernel(fun,lb,ub,o,mark)
% Double-tree metric TSP approximation: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  N=size(W,1);
  assert(norm(W-W','fro')<1e-10 || isequaln(W,W'));
  edges=[];
  selected=false(N,1);
  selected(1)=true;
  while sum(selected)<N
    best=Inf;
    pair=[];
    for i=find(selected)'
      for j=find(~selected)'
        if W(i,j)<best
          best=W(i,j);
          pair=[i j];
        end
      end
    end
    assert(~isempty(pair),'Graph is disconnected.');
    edges=[edges;pair];
    selected(pair(2))=true;
    mark();
    %#ok<AGROW>
  end
  assert(size(edges,1)==N-1,'Graph is disconnected.');
  extra.edges=edges;
  adjacency=false(N);
  for j=1:size(edges,1)
    adjacency(edges(j,1),edges(j,2))=true;
    adjacency(edges(j,2),edges(j,1))=true;
  end
  stack=1;
  seen=false(N,1);
  tour=[];
  while ~isempty(stack)
    i=stack(end);
    stack(end)=[];
    if seen(i)
      continue;
    end
    seen(i)=true;
    tour(end+1)=i;
    stack=[stack find(adjacency(i,:) & ~seen')];
    %#ok<AGROW>
  end
  x=tour(:);
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
