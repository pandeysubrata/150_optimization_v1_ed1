function [x,extra]=sade_kernel(fun,lb,ub,o,mark)
% SaDE: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  n=numel(lb);
  N=o.popSize;
  x=o.x0;
  extra=struct();
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(1,N);
  for i=1:N
    F(i)=fun(X(:,i));
  end
  archive=zeros(n,0);
  MF=.5*ones(1,6);
  MC=MF;
  pos=1;
  indivF=.5*ones(1,N);
  indivCR=.9*ones(1,N);
  probs=ones(1,4)/4;
  success=ones(1,4);
  trials=2*ones(1,4);
  for k=1:o.maxIter
    [~,rank]=sort(F);
    oldX=X;
    oldF=F;
    sf=[];
    sc=[];
    gain=[];
    for i=1:N
      ids=randperm(N);
      ids(ids==i)=[];
      strategy=1;
      strategy=find(rand<=cumsum(probs),1);
      ff=min(1,max(.1,.5+.3*randn));
      cr=min(1,max(0,.5+.1*randn));
      trials(strategy)=trials(strategy)+1;
      a=oldX(:,ids(1));
      b=oldX(:,ids(2));
      c=oldX(:,ids(3));
      d=oldX(:,ids(4));
      e=oldX(:,ids(5));
      best=oldX(:,rank(1));
      switch strategy
      case 1
        y=a+ff*(b-c);
      case 2
        y=oldX(:,i)+ff*(best-oldX(:,i))+ff*(a-b)+ff*(c-d);
      case 3
        y=a+ff*(b-c)+ff*(d-e);
      case 4
        y=oldX(:,i)+rand*(a-oldX(:,i))+ff*(b-c);
      end
      mask=rand(n,1)<cr;
      mask(randi(n))=true;
      if strategy==4
        mask(:)=true;
      end
      y(~mask)=oldX(~mask,i);
      y=min(ub,max(lb,y));
      fy=fun(y);
      if fy<oldF(i)
        archive=[archive oldX(:,i)];
        X(:,i)=y;
        F(i)=fy;
        sf(end+1)=ff;
        sc(end+1)=cr;
        gain(end+1)=oldF(i)-fy;
        indivF(i)=ff;
        indivCR(i)=cr;
        success(strategy)=success(strategy)+1;
      end
    end
    if size(archive,2)>N
      archive=archive(:,randperm(size(archive,2),N));
    end
    if ~isempty(sf)
      w=gain/sum(gain);
      MF(pos)=sum(w.*sf.^2)/sum(w.*sf);
      MC(pos)=sum(w.*sc);
      pos=mod(pos,6)+1;
    end
    if mod(k,10)==0
      probs=success./trials;
      probs=probs/sum(probs);
      success=ones(1,4);
      trials=2*ones(1,4);
    end
    mark();
  end
  [~,i]=min(F);
  x=X(:,i);
  extra.memoryF=MF;
  extra.memoryCR=MC;
  extra.scope='educational variant: iteration-based population reduction and simplified adaptation';
end
