function [x,extra]=branch_bound_kernel(fun,lb,ub,o,mark)
% Branch and bound for binary knapsack: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  w=p.weights(:);
  assert(all(w>0 & w==floor(w)));
  capacity=p.capacity;
  assert(capacity>=0 && capacity==floor(capacity));
  value=p.values(:);
  [~,order]=sort(value./w,'descend');
  ws=w(order);
  vs=value(order);
  best=0;
  bestBits=zeros(n,1);
  nodes=0;
  search(1,0,0,zeros(n,1));
  x(order)=bestBits;
  extra.nodes=nodes;
  extra.optimal=(nodes<o.maxIter);
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
      bestBits=bits;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
