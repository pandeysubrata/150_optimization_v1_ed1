function [x,extra]=lookahead_kernel(fun,lb,ub,o,mark)
% Lookahead: explicit method kernel.
  % Educational adaptive/hybrid recipes. See variant ledger before citation.
  x=o.x0;
  extra=struct();
  slow=x;
  for k=1:o.maxIter
    for j=1:5
      g=cbGradient(fun,x,lb,ub,o);
      x=min(ub,max(lb,x-o.alpha*g));
    end
    slow=slow+.5*(x-slow);
    x=slow;
    fun(x);
    mark();
  end
  extra.inner='five gradient steps; synchronization weight 0.5';
  return;
end
