function [x,extra]=cma_es_kernel(fun,lb,ub,o,mark)
% CMA-ES: explicit method kernel.
  [x,extra]=cbCMA(fun,lb,ub,o,mark);
  return;
end
