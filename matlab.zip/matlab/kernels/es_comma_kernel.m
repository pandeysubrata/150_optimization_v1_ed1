function [x,extra]=es_comma_kernel(fun,lb,ub,o,mark)
% Mu-comma-lambda evolution strategy: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=false;

  for j=1:N
    F(j)=fun(X(:,j));
  end
  sigma=o.sigma*span;
  individualSigma=repmat(sigma,1,N);
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    mu=max(2,floor(N/3));
    [~,order]=sort(F);
    parents=X(:,order(1:mu));
    parentSigma=individualSigma(:,order(1:mu));
    children=zeros(n,N);
    childSigma=children;
    CF=F;
    for j=1:N
      ids=randi(mu,1,2);
      center=mean(parents(:,ids),2);
      scale=mean(parentSigma(:,ids),2);
      scale=scale.*exp(randn/sqrt(2*n)+randn(n,1)/sqrt(2*sqrt(n)));
      children(:,j)=min(ub,max(lb,center+scale.*randn(n,1)));
      childSigma(:,j)=scale;
      CF(j)=fun(children(:,j));
    end
    pool=children;
    poolF=CF;
    scales=childSigma;
    [~,order]=sort(poolF);
    X=pool(:,order(1:N));
    F=poolF(order(1:N));
    individualSigma=scales(:,order(1:N));
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
