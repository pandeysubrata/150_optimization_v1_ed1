function [x,extra]=extra_kernel(fun,lb,ub,o,mark)
% EXTRA: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  A=o.centers;
  W=o.mixing;
  M=size(A,2);
  assert(all(size(W)==[M M]) && norm(W-W')<1e-10 && norm(sum(W,1)-1)<1e-10);
  Z=repmat(x,1,M);
  G=Z-A;
  oldZ=Z;
  oldG=G;
  for k=1:o.maxIter
    if k>1
      next=Z*(eye(M)+W)-oldZ*(eye(M)+W)/2-o.alpha*(G-oldG);
      newG=next-A;
    else
      next=Z*W-o.alpha*G;
      newG=next-A;
    end
    oldZ=Z;
    oldG=G;
    Z=next;
    G=newG;
    x=min(ub,max(lb,mean(Z,2)));
    fun(x);
    mark();
  end
  extra.consensusResidual=norm(Z-mean(Z,2),'fro');
  extra.localDecisions=Z;
end
