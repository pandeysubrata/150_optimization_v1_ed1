function [x,extra]=cross_entropy_kernel(fun,lb,ub,o,mark)
% Cross-entropy search: explicit method kernel.
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  binary=false;

  for j=1:N
    F(j)=fun(X(:,j));
  end
  meanPoint=mean(X,2);
  sigma=o.sigma*span;
  [best,j]=min(F);
  x=X(:,j);
  for k=1:o.maxIter
    X=min(ub,max(lb,meanPoint+sigma.*randn(n,N)));
    for j=1:N
      F(j)=fun(X(:,j));
    end
    [~,order]=sort(F);
    elite=X(:,order(1:max(2,ceil(0.2*N))));
    meanPoint=0.7*mean(elite,2)+0.3*meanPoint;
    sigma=max(1e-6*span,0.7*std(elite,0,2)+0.3*sigma);
    [value,j]=min(F);
    if value<best
      best=value;
      x=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','domainBinary',binary);
end
