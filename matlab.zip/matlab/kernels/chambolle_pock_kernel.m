function [x,extra]=chambolle_pock_kernel(fun,lb,ub,o,mark)
% Chambolle-Pock primal-dual: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  % min 0.5*||x-b||^2+lambda*||D*x||_1.
  D=p.D;
  b=p.b(:);
  dual=zeros(size(D,1),1);
  extrap=x;
  tau=0.99/max(1,norm(D));
  sigma=tau;
  for k=1:o.maxIter
    dual=min(o.lambda,max(-o.lambda,dual+sigma*D*extrap));
    old=x;
    x=(x-tau*D'*dual+tau*b)/(1+tau);
    extrap=2*x-old;
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
