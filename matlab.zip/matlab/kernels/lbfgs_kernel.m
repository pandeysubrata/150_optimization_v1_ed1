function [x,extra]=lbfgs_kernel(fun,lb,ub,o,mark)
% Limited-memory BFGS: explicit method kernel.
  % Distinct update rules share finite differences, bounds and logging.
  x=o.x0;
  f=fun(x);
  S=[];
  Y=[];
  extra=struct('implementation','Bounded educational adaptation','stop','iteration budget');
  for k=1:o.maxIter
    g=cbGradient(fun,x,lb,ub,o);
    if norm(x-min(ub,max(lb,x-g)),Inf)<o.tolerance
      extra.stop='projected gradient';
      break;
    end
    q=g;
    m=size(S,2);
    al=zeros(m,1);
    rh=zeros(m,1);
    for j=m:-1:1
      rh(j)=1/(Y(:,j)'*S(:,j));
      al(j)=rh(j)*(S(:,j)'*q);
      q=q-al(j)*Y(:,j);
    end
    scale=1;
    if m>0
      scale=(S(:,m)'*Y(:,m))/(Y(:,m)'*Y(:,m));
    end
    d=scale*q;
    for j=1:m
      be=rh(j)*(Y(:,j)'*d);
      d=d+S(:,j)*(al(j)-be);
    end
    d=-d;
    if g'*d>=-1e-12*norm(g)*max(norm(d),eps)
      d=-g;
    end
    [z,fz]=cbLine(fun,x,f,g,d,lb,ub);
    s=z-x;
    y=cbGradient(fun,z,lb,ub,o)-g;
    sy=s'*y;
    if sy>1e-10*norm(s)*max(norm(y),eps)
      S=[S s];
      Y=[Y y];
      if size(S,2)>o.memory
        S=S(:,2:end);
        Y=Y(:,2:end);
      end
    end
    change=norm(z-x,Inf);
    x=z;
    f=fz;
    mark();
    if change<o.tolerance
      extra.stop='small displacement';
      break;
    end
  end
end
