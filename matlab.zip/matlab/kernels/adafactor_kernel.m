function [x,extra]=adafactor_kernel(fun,lb,ub,o,mark)
% Matrix-block Adafactor: row/column moments, RMS clipping, relative step.
x=o.x0; shape=o.matrixShape;
assert(prod(shape)==numel(x) && numel(shape)==2);
r=zeros(shape(1),1); c=zeros(1,shape(2));
for k=1:o.maxIter
    G=reshape(o.sampleGrad(x,randi(o.numSamples)),shape);
    beta=1-k^(-0.8); squares=G.^2+1e-30;
    r=beta*r+(1-beta)*mean(squares,2);
    c=beta*c+(1-beta)*mean(squares,1);
    V=(r*c)/max(mean(r),realmin);
    U=G./sqrt(V); U=U/max(1,sqrt(mean(U(:).^2)));
    rate=min(o.alpha,1/sqrt(k))*max(1e-3,sqrt(mean(x.^2)));
    x=x-rate*U(:); x=min(ub,max(lb,x));
    fun(x); mark();
end
extra=struct('rowMoment',r,'columnMoment',c);
end
