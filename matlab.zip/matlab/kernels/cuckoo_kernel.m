function [bestX,extra]=cuckoo_kernel(fun,lb,ub,o,mark)
% Cuckoo search: explicit method kernel.
name='cuckoo';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      candidate=current+0.01*cbLevy(n).*(current-bestX);
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=true;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    for i=1:N
      if rand<0.25
        ids=randperm(N,2);
        candidate=clip(X(:,i)+rand*(X(:,ids(1))-X(:,ids(2))));
        value=fun(candidate);
        if value<F(i)
          X(:,i)=candidate;
          F(i)=value;
        end
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
