function [x,extra]=dual_ascent_kernel(fun,lb,ub,o,mark)
% Dual gradient ascent: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');
  if isfield(o,'problem')
    p=o.problem;
  else
    p=struct();
  end
  % Strictly convex quadratic with equalities: min .5*x'*Q*x+c'*x, A*x=b.
  Q=p.Q;
  c=p.c(:);
  A=p.A;
  b=p.b(:);
  y=zeros(size(A,1),1);
  for k=1:o.maxIter
    x=-Q\(c+A'*y);
    residual=A*x-b;
    y=y+o.alpha*residual;
    fun(x);
    mark();
    if norm(residual,Inf)<o.tolerance
      break;
    end
  end
  extra.multiplier=y;
  fun(x);
end
