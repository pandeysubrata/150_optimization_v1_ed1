function [x,extra]=nadam_kernel(fun,lb,ub,o,mark)
% Nadam: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  first=zeros(n,1);
  second=first;
  b1=0.9;
  b2=0.999;
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    first=b1*first+(1-b1)*g;
    second=b2*second+(1-b2)*g.^2;
    mh=first/(1-b1^k);
    vh=second/(1-b2^k);
    mh=b1*mh+(1-b1)*g/(1-b1^k);
    change=o.alpha*mh./(sqrt(vh)+o.epsilon);
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
