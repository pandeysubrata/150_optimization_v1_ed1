function [x,extra]=paes_kernel(fun,lb,ub,o,mark)
% Pareto archived evolution strategy: explicit method kernel.
  % Two-objective teaching implementations. Columns are decision vectors.
  % All objective calls are archived by cbSolve; no scalar best is implied.
  n=numel(lb);
  N=o.popSize;
  X=lb+(ub-lb).*rand(n,N);
  F=zeros(N,2);
  for i=1:N
    F(i,:)=fun(X(:,i));
  end
  assert(size(F,2)==2,'These recipes require two objectives.');
  gridBins=10;
  X=X(:,1);
  F=F(1,:);
  AX=X;
  AF=F;
  for k=1:o.maxIter
    y=min(ub,max(lb,X+.1*(ub-lb).*randn(n,1)));
    fy=fun(y);
    if all(fy<=F)
      X=y;
      F=fy;
    elseif ~all(F<=fy)
      % Finite adaptive-grid archive: favor the less populated cell.
      if k==1
        AX=X;
        AF=F;
      end
      AX=[AX y];
      AF=[AF;fy];
      keep=cbNondominated(AF);
      AX=AX(:,keep);
      AF=AF(keep,:);
      lo=min(AF,[],1);
      span=max(max(AF,[],1)-lo,eps);
      cells=floor(gridBins*(AF-lo)./span);
      cy=floor(gridBins*(fy-lo)./span);
      cx=floor(gridBins*(F-lo)./span);
      if sum(all(cells==cy,2))<=sum(all(cells==cx,2))
        X=y;
        F=fy;
      end
      if size(AF,1)>N
        [~,~,g]=unique(cells,'rows');
        counts=accumarray(g,1);
        [~,crowd]=max(counts(g));
        AX(:,crowd)=[];
        AF(crowd,:)=[];
      end
    end
    mark();
  end
  x=X(:,1);
  extra=struct('population',X,'objectives',F,'scope','two-objective educational variant');
end
