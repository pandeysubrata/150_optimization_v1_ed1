function [bestX,extra]=gsa_kernel(fun,lb,ub,o,mark)
% Gravitational search algorithm: explicit method kernel.
name='gsa';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  V=zeros(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      count=max(1,ceil(N*(1-k/o.maxIter)));
      force=zeros(n,1);
      for j=rank(1:count)
        if j~=i
          distance=norm((old(:,j)-current)./span);
          force=force+rand*mass(j)*(old(:,j)-current)/(distance+1e-12);
        end
      end
      acceleration=10*exp(-20*k/o.maxIter)*force;
      V(:,i)=rand(n,1).*V(:,i)+acceleration;
      candidate=current+V(:,i);
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=false;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
