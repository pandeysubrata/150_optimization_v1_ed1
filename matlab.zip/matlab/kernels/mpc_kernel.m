function [x,extra]=mpc_kernel(fun,lb,ub,o,mark)
% Receding-horizon MPC: explicit method kernel.
  % Explicit finite-scenario, quadratic-agent and linear-control specializations.
  x=o.x0;
  extra=struct();
  % A single finite-horizon MPC optimization. Receding-horizon demo re-calls it.
  % State constraints are not implemented; input box is enforced.
  H=o.horizon;
  A=o.A;
  B=o.B;
  Q=o.Q;
  R=o.R;
  nu=size(B,2);
  nx=size(A,1);
  for k=1:o.maxIter
    path=zeros(nx,H+1);
    path(:,1)=o.initialState;
    for t=1:H
      ids=(t-1)*nu+(1:nu);
      path(:,t+1)=A*path(:,t)+B*x(ids);
    end
    adj=2*o.Qf*path(:,end);
    g=zeros(size(x));
    for t=H:-1:1
      ids=(t-1)*nu+(1:nu);
      g(ids)=2*R*x(ids)+B'*adj;
      adj=2*Q*path(:,t)+A'*adj;
    end
    fx=fun(x);
    [y,~]=cbLine(fun,x,fx,g,-g,lb,ub);
    mark();
    if norm(y-x)<o.tolerance
      x=y;
      break;
    end
    x=y;
  end
  extra.prediction=path;
  extra.firstMove=x(1:nu);
end
