function [bestX,extra]=ant_colony_system_kernel(fun,lb,ub,o,mark)
% Ant Colony System: explicit method kernel.
name='ant_colony_system';
  n=numel(lb);
  [bestX,extra]=ants(name,fun,o,mark);
  return;
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
function j=roulette(p)
  u=rand;
  j=find(cumsum(p)>=u,1);
  if isempty(j)
    j=numel(p);
  end
end
function [bestTour,extra]=ants(name,fun,o,mark)
  W=o.problem.graph;
  n=size(W,1);
  tau0=1/(n*max(1,mean(W(:))));
  tau=tau0*ones(n);
  eta=1./max(W,1e-12);
  eta(1:n+1:end)=0;
  best=Inf;
  bestTour=(1:n)';
  rho=0.2;
  for k=1:o.maxIter
    tours=zeros(n,o.popSize);
    values=zeros(1,o.popSize);
    for ant=1:o.popSize
      tour=zeros(n,1);
      tour(1)=randi(n);
      visited=false(n,1);
      visited(tour(1))=true;
      for position=2:n
        i=tour(position-1);
        available=find(~visited);
        score=tau(i,available).*eta(i,available).^2;
        if rand<0.9
          [~,j]=max(score);
        else
          score=score/max(sum(score),realmin);
          j=roulette(score);
        end
        next=available(j);
        tour(position)=next;
        visited(next)=true;
        tau(i,next)=0.9*tau(i,next)+0.1*tau0;
        tau(next,i)=tau(i,next);
      end
      a= tour(end); b=tour(1);
      tau(a,b)=0.9*tau(a,b)+0.1*tau0; tau(b,a)=tau(a,b);
      tours(:,ant)=tour;
      values(ant)=fun(tour);
    end
    [value,j]=min(values);
    if value<best
      best=value;
      bestTour=tours(:,j);
    end
    % Global update touches only best-tour edges in ACS.
    selected=j;
    for ant=selected
      tour=tours(:,ant);
      deposit=1/max(values(ant),1e-12);
      tour=bestTour;
      deposit=rho/max(best,1e-12);
      for q=1:n
        i=tour(q);
        jnext=tour(mod(q,n)+1);
        tau(i,jnext)=(1-rho)*tau(i,jnext)+deposit;
        tau(jnext,i)=tau(i,jnext);
      end
    end
    mark();
  end
  extra=struct('stop','iteration budget','pheromone',tau);
end
