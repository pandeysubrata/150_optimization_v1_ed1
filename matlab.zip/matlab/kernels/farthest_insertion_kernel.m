function [x,extra]=farthest_insertion_kernel(fun,lb,ub,o,mark)
% Farthest-insertion TSP heuristic: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  N=size(W,1);
  [~,far]=max(W(1,:));
  tour=[1 far];
  remaining=setdiff(1:N,tour);
  while ~isempty(remaining)
    distance=min(W(remaining,tour),[],2);
    [~,q]=max(distance);
    city=remaining(q);
    increase=Inf;
    where=1;
    for j=1:numel(tour)
      next=tour(mod(j,numel(tour))+1);
      gain=W(tour(j),city)+W(city,next)-W(tour(j),next);
      if gain<increase
        increase=gain;
        where=j;
      end
    end
    tour=[tour(1:where) city tour(where+1:end)];
    remaining(q)=[];
  end
  x=tour(:);
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
