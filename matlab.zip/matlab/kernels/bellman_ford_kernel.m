function [x,extra]=bellman_ford_kernel(fun,lb,ub,o,mark)
% Bellman-Ford shortest path: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  source=p.source;
  N=size(W,1);
  assert(N==n);
  distance=Inf(N,1);
  distance(source)=0;
  parent=zeros(N,1);
  for k=1:N-1
    changed=false;
    for i=1:N
      for j=1:N
        if isfinite(W(i,j)) && distance(i)+W(i,j)<distance(j)
          distance(j)=distance(i)+W(i,j);
          parent(j)=i;
          changed=true;
        end
      end
    end
    mark();
    if ~changed
      break;
    end
  end
  for i=1:N
    for j=1:N
      assert(~(isfinite(W(i,j)) && distance(i)+W(i,j)<distance(j)-1e-12),'Reachable negative cycle.');
    end
  end
  x=parent;
  extra.distance=distance;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
