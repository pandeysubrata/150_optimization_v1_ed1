function [x,extra]=coordinate_descent_kernel(fun,lb,ub,o,mark)
% Exact bounded coordinate minimizations using a safeguarded scalar search.
x=o.x0; n=numel(x);
for k=1:o.maxIter
    old=x;
    for j=1:n
        objective=@(t)fun(replaceCoordinate(x,j,t));
        [t,~]=cbScalar(objective,lb(j),ub(j),o.tolerance,40,true);
        x(j)=t;
    end
    fun(x); mark();
    if norm(x-old,Inf)<o.tolerance, break; end
end
extra=struct('sweeps',k);
end
function y=replaceCoordinate(x,j,t)
y=x; y(j)=t;
end
