function [x,extra]=augmented_lagrangian_kernel(fun,lb,ub,o,mark)
% Augmented Lagrangian: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');

  assert(isfield(o,'equalities') && isfield(o,'constraintJac'),'Equality callbacks required.');
  c=o.equalities(x);
  multiplier=zeros(numel(c),1);
  rho=o.rho;
  for k=1:o.maxIter
    inner=o;
    inner.maxIter=10;
    inner.x0=x;
    if isfield(inner,'grad')
      inner=rmfield(inner,'grad');
    end
    if isfield(inner,'hess')
      inner=rmfield(inner,'hess');
    end
    merit=@(z) fun(z)+multiplier'*o.equalities(z)+rho/2*sum(o.equalities(z).^2);
    [x,~]=bfgs_kernel(merit,lb,ub,inner,@() 0);
    c=o.equalities(x);
    multiplier=multiplier+rho*c;
    if norm(c)>0.25
      rho=min(1e6,2*rho);
    end
    fun(x);
    mark();
    if norm(o.equalities(x),Inf)<o.tolerance && k>5
      break;
    end
  end
  fun(x);
end
