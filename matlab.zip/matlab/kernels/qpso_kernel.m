function [bestX,extra]=qpso_kernel(fun,lb,ub,o,mark)
% Quantum-behaved PSO: explicit method kernel.
name='qpso';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      leader=bestX;
      phi=rand(n,1);
      attractor=phi.*P(:,i)+(1-phi).*leader;
      beta=1-0.5*k/o.maxIter;
      direction=2*(rand(n,1)>0.5)-1;
      candidate=attractor+direction.*beta.*abs(mean(P,2)-current).*log(1./max(rand(n,1),realmin));
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=false;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
