function [x,extra]=rmsprop_kernel(fun,lb,ub,o,mark)
% RMSprop: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  first=zeros(n,1);
  second=first;
  for k=1:o.maxIter
    index=randi(N);
    g=o.sampleGrad(x,index);
    second=0.9*second+0.1*g.^2;
    change=o.alpha*g./(sqrt(second)+o.epsilon);
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
