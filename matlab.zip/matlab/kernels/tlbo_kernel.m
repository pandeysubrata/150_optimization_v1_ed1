function [bestX,extra]=tlbo_kernel(fun,lb,ub,o,mark)
% Teaching-learning-based optimization: explicit method kernel.
name='tlbo';
  n=numel(lb);
  N=o.popSize;
  span=ub-lb;
  X=lb+span.*rand(n,N);
  F=zeros(1,N);
  for j=1:N
    F(j)=fun(X(:,j));
  end
  P=X;
  PF=F;
  [best,j]=min(F);
  bestX=X(:,j);
  for k=1:o.maxIter
    old=X;
    oldF=F;
    [~,rank]=sort(F);
    meanPoint=mean(X,2);
    mass=(F-max(F))/(min(F)-max(F)+eps);
    mass=max(0,mass);
    mass=mass/max(sum(mass),eps);
    if sum(mass)==0
      mass=ones(1,N)/N;
    end
    for i=1:N
      current=old(:,i);
      candidate=current;
      teachingFactor=1+(rand>0.5);
      candidate=current+rand(n,1).*(bestX-teachingFactor*meanPoint);
      candidate=clip(candidate);
      value=fun(candidate);
      greedy=true;
      accept=~greedy || value<oldF(i);
      if accept
        X(:,i)=candidate;
        F(i)=value;
      end
      j=randi(N-1);
      if j>=i
        j=j+1;
      end
      signMove=1;
      if F(i)>F(j)
        signMove=-1;
      end
      candidate=clip(X(:,i)+signMove*rand(n,1).*(X(:,i)-X(:,j)));
      value=fun(candidate);
      if value<F(i)
        X(:,i)=candidate;
        F(i)=value;
      end
    end
    better=F<PF;
    P(:,better)=X(:,better);
    PF(better)=F(better);
    [value,j]=min(F);
    if value<best
      best=value;
      bestX=X(:,j);
    end
    mark();
  end
  extra=struct('stop','iteration budget','boundary','clipping','population',N);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
end
