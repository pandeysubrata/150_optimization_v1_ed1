function [x,extra]=ellipsoid_kernel(fun,lb,ub,o,mark)
% Ellipsoid method: explicit method kernel.
  x=o.x0;
  n=numel(x);
  extra=struct('stop','iteration budget');

  assert(n>1,'This ellipsoid update requires dimension at least two.');
  x=(lb+ub)/2;
  E=diag(((ub-lb)/2).^2)*n;
  for k=1:o.maxIter
    if any(x<lb)
      j=find(x<lb,1);
      g=zeros(n,1);
      g(j)=-1;
    elseif any(x>ub)
      j=find(x>ub,1);
      g=zeros(n,1);
      g(j)=1;
    else
      fun(x);
      g=cbGradient(fun,x,lb,ub,o);
    end
    q=g'*E*g;
    if q<o.tolerance^2
      break;
    end
    v=E*g/sqrt(q);
    x=x-v/(n+1);
    E=n^2/(n^2-1)*(E-2/(n+1)*(v*v'));
    E=(E+E')/2;
    mark();
  end
  x=min(ub,max(lb,x));
  fun(x);
end
