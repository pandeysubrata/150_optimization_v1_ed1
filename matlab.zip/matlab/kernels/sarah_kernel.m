function [x,extra]=sarah_kernel(fun,lb,ub,o,mark)
% SARAH: explicit method kernel.
  assert(isfield(o,'sampleGrad') && isfield(o,'numSamples'),'Finite-sum sampleGrad(x,i) and numSamples required.');
  x=o.x0;
  n=numel(x);
  N=o.numSamples;
  snapshot=x;
  full=zeros(n,1);
  estimate=[];
  previous=x;
  for k=1:o.maxIter
    if mod(k-1,N)==0
      snapshot=x;
      full=zeros(n,1);
      for i=1:N
        full=full+o.sampleGrad(snapshot,i)/N;
      end
      estimate=full;
      previous=x;
    end
    index=randi(N);
    g=o.sampleGrad(x,index);
    if mod(k-1,N)~=0
      estimate=g-o.sampleGrad(previous,index)+estimate;
    end
    g=estimate;
    previous=x;
    change=o.alpha*g;
    x=min(ub,max(lb,x-change));
    fun(x);
    mark();
  end
  extra=struct('stop','iteration budget','numSamples',N,   'note','Full objective is logged each iteration; count this monitoring cost.');
end
