function [x,extra]=nelder_mead_kernel(fun,lb,ub,o,mark)
% Nelder-Mead: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  X=repmat(x,1,n+1);
  for j=1:n
    delta=0.05*span(j);
    X(j,j+1)=min(ub(j),x(j)+delta);
    if X(j,j+1)==x(j)
      X(j,j+1)=max(lb(j),x(j)-delta);
    end
  end
  F=zeros(1,n+1);
  for j=1:n+1
    F(j)=fun(X(:,j));
  end
  for k=1:o.maxIter
    [F,order]=sort(F);
    X=X(:,order);
    center=mean(X(:,1:n),2);
    reflect=clip(center+(center-X(:,end)));
    fr=fun(reflect);
    if fr<F(1)
      expand=clip(center+2*(reflect-center));
      fe=fun(expand);
      if fe<fr
        X(:,end)=expand;
        F(end)=fe;
      else
        X(:,end)=reflect;
        F(end)=fr;
      end
    elseif fr<F(n)
      X(:,end)=reflect;
      F(end)=fr;
    else
      if fr<F(end)
        contract=clip(center+0.5*(reflect-center));
        threshold=fr;
      else
        contract=clip(center+0.5*(X(:,end)-center));
        threshold=F(end);
      end
      fc=fun(contract);
      if fc<=threshold
        X(:,end)=contract;
        F(end)=fc;
      else
        for j=2:n+1
          X(:,j)=X(:,1)+0.5*(X(:,j)-X(:,1));
          F(j)=fun(X(:,j));
        end
      end
    end
    mark();
    if max(max(abs(X-X(:,1))))<o.tolerance
      break;
    end
  end
  [~,j]=min(F);
  x=X(:,j);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
