function [x,extra]=direct_kernel(fun,lb,ub,o,mark)
% DIRECT: explicit method kernel.
  n=numel(lb);
  x=o.x0;
fun(x);
  span=ub-lb;
  extra=struct('stop','iteration budget');
  centers=0.5*ones(n,1);
  widths=0.5*ones(n,1);
  values=fun(lb+span.*centers);
  for k=1:o.maxIter
    sizes=sqrt(sum(widths.^2,1));
    fmin=min(values);
    chosen=[];
    for i=1:numel(values)
      low=0;
      high=Inf;
      possible=true;
      for j=1:numel(values)
        ds=sizes(i)-sizes(j);
        df=values(i)-values(j);
        if abs(ds)<1e-14
          if df>1e-12
            possible=false;
            break;
          end
        elseif ds>0
          low=max(low,df/ds);
        else
          high=min(high,df/ds);
        end
      end
      low=max(low,(values(i)-fmin+1e-4*abs(fmin))/max(sizes(i),eps));
      if possible && high>=max(low,0)
        chosen(end+1)=i;
      end
      %#ok<AGROW>
    end
    for i=chosen
      longest=max(widths(:,i));
      dims=find(abs(widths(:,i)-longest)<1e-14);
      pairValues=zeros(2,numel(dims));
      for q=1:numel(dims)
        shift=zeros(n,1);
        shift(dims(q))=2*longest/3;
        pairValues(1,q)=fun(lb+span.*(centers(:,i)+shift));
        pairValues(2,q)=fun(lb+span.*(centers(:,i)-shift));
      end
      [~,order]=sort(min(pairValues,[],1));
      for q=order
        j=dims(q);
        widths(j,i)=widths(j,i)/3;
        shift=zeros(n,1);
        shift(j)=2*longest/3;
        centers=[centers centers(:,i)+shift centers(:,i)-shift];
        %#ok<AGROW>
        widths=[widths widths(:,i) widths(:,i)];
        values=[values pairValues(:,q)'];
        %#ok<AGROW>
      end
    end
    mark();
    if min(sizes)<o.tolerance
      break;
    end
  end
  [~,j]=min(values);
  x=lb+span.*centers(:,j);
  function z=clip(z)
    z=min(ub,max(lb,z));
  end
  function e=eyeColumn(j)
    e=zeros(n,1);
    e(j)=1;
  end
  function [z,fz]=lineMin(base,direction)
    low=-Inf;
    high=Inf;
    for q=1:n
      if abs(direction(q))>1e-14
        limits=sort([(lb(q)-base(q))/direction(q),(ub(q)-base(q))/direction(q)]);
        low=max(low,limits(1));
        high=min(high,limits(2));
      end
    end
    if ~isfinite(low) || high-low<1e-12
      z=base;
      fz=fun(z);
      return;
    end
    [a,fz]=cbScalar(@(t) fun(base+t*direction),low,high,1e-6,40,true);
    z=base+a*direction;
  end
end
