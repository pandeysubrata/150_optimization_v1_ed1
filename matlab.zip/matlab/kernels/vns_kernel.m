function [bestTour,extra]=vns_kernel(fun,lb,ub,o,mark)
% Variable neighborhood search: explicit method kernel.
  % These local-search recipes use symmetric TSP tours, not arbitrary vectors.
  W=o.problem.graph;
  n=size(W,1);
  tour=(1:n)';
  current=fun(tour);
  best=current;
  bestTour=tour;
  temperature=max(1e-8,0.1*abs(current));
  threshold=temperature;
  neighborhood=2;
  for k=1:o.maxIter
    z=tour;
    changes=2;
    changes=neighborhood;
    for q=1:changes
      ids=sort(randperm(n,2));
      z(ids(1):ids(2))=flipud(z(ids(1):ids(2)));
    end
    [z,fz]=improve(z,zeros(n));
    accept=fz<current;
    if accept
      tour=z;
      current=fz;
    end
    if fz<best
      best=fz;
      bestTour=z;
    end
    if accept
      neighborhood=2;
    else
      neighborhood=mod(neighborhood,5)+1;
    end
    temperature=0.97*temperature;
    threshold=0.97*threshold;
    mark();
  end
  extra=struct('stop','iteration budget','specialization','symmetric TSP','bestTourCost',best);
  function [z,value]=improve(z,penalty)
    value=fun(z);
    augmented=value+edgePenalty(z,penalty);
    for sweep=1:10
      changed=false;
      for a=2:n-1
        for b=a+1:n
          candidate=z;
          candidate(a:b)=flipud(candidate(a:b));
          cost=fun(candidate);
          score=cost+edgePenalty(candidate,penalty);
          if score<augmented
            z=candidate;
            value=cost;
            augmented=score;
            changed=true;
          end
        end
      end
      if ~changed
        break;
      end
    end
  end
end
function value=edgePenalty(tour,P)
  value=0;
  n=numel(tour);
  for k=1:n
    value=value+P(tour(k),tour(mod(k,n)+1));
  end
end
