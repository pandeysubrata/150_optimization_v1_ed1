function [x,extra]=fista_kernel(fun,lb,ub,o,mark)
% FISTA: explicit method kernel.
  x=o.x0;
  extra=struct('stop','iteration budget');

  y=x;
  t=1;
  for k=1:o.maxIter
    old=x;
    g=cbGradient(fun,y,lb,ub,o);
    assert(isfield(o,'prox'),'Supply options.prox(z,step) and smooth gradient.');
    base=y;
    x=o.prox(base-o.alpha*g,o.alpha);
    x=min(ub,max(lb,x));
    tn=(1+sqrt(1+4*t^2))/2;
    y=x+(t-1)/tn*(x-old);
    t=tn;
    fun(x);
    mark();
    if norm(x-old,Inf)<o.tolerance
      break;
    end
  end
  fun(x);
end
