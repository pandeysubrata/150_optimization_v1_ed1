function [x,extra]=floyd_warshall_kernel(fun,lb,ub,o,mark)
% Floyd-Warshall all-pairs paths: explicit method kernel.
  p=o.problem;
  extra=struct('stop','completed');
  n=numel(lb);
  x=zeros(n,1);
  W=p.graph;
  source=p.source;
  N=size(W,1);
  assert(N==n);
  D=W;
  D(1:N+1:end)=min(diag(D),0);
  for k=1:N
    for i=1:N
      for j=1:N
        D(i,j)=min(D(i,j),D(i,k)+D(k,j));
      end
    end
    mark();
  end
  assert(all(diag(D)>=0),'Negative cycle detected.');
  x=D(source,:)';
  extra.allPairs=D;
  fun(x);
  mark();
  function search(i,weight,profit,bits)
    if nodes>=o.maxIter
      return;
    end
    nodes=nodes+1;
    if profit>best
      best=profit;
    end
    if i>n
      return;
    end
    bound=profit;
    room=capacity-weight;
    for j=i:n
      take=min(1,room/ws(j));
      bound=bound+take*vs(j);
      room=room-take*ws(j);
      if room<=0
        break;
      end
    end
    if bound<=best
      return;
    end
    if weight+ws(i)<=capacity
      next=bits;
      next(i)=1;
      search(i+1,weight+ws(i),profit+vs(i),next);
    end
    search(i+1,weight,profit,bits);
  end
end
