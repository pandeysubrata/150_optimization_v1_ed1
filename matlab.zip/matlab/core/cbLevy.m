function step=cbLevy(n)
% Mantegna symmetric stable-flight construction, beta=1.5.
beta=1.5; scale=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
step=scale*randn(n,1)./max(abs(randn(n,1)),1e-12).^(1/beta);
end
