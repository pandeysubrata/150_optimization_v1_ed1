function [x,fx]=cbScalar(fun,a,b,tol,maxIter,useParabola)
% Bounded Brent-style search; golden-only when useParabola=false.
golden=(3-sqrt(5))/2; x=a+golden*(b-a); w=x; v=x;
fx=fun(x); fw=fx; fv=fx; step=0; previous=0;
for k=1:maxIter
 middle=(a+b)/2; t=tol*abs(x)+tol/10;
 if abs(x-middle)<=2*t-(b-a)/2, break; end
 accepted=false;
 if useParabola && abs(previous)>t
  r=(x-w)*(fx-fv); q=(x-v)*(fx-fw);
  p=(x-v)*q-(x-w)*r; q=2*(q-r);
  if q>0, p=-p; else, q=-q; end
  old=previous; previous=step;
  if q>0 && abs(p)<abs(q*old/2) && p>q*(a-x) && p<q*(b-x)
   step=p/q; accepted=true;
   if x+step-a<2*t || b-x-step<2*t, step=sign(middle-x+eps)*t; end
  end
 end
 if ~accepted
  if x<middle, previous=b-x; else, previous=a-x; end
  step=golden*previous;
 end
 direction=sign(step); if direction==0, direction=1; end
 u=x+direction*max(abs(step),t); fu=fun(u);
 if fu<=fx
  if u<x, b=x; else, a=x; end
  v=w; fv=fw; w=x; fw=fx; x=u; fx=fu;
 else
  if u<x, a=u; else, b=u; end
  if fu<=fw || w==x, v=w; fv=fw; w=u; fw=fu;
  elseif fu<=fv || v==x || v==w, v=u; fv=fu; end
 end
end
end
