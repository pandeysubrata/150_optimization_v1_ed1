function y=cbPolynomialMutation(x,lb,ub,eta,probability)
% Deb's bounded polynomial mutation, applied independently per coordinate.
y=x;
for j=1:numel(x)
    if rand>probability || ub(j)<=lb(j), continue; end
    span=ub(j)-lb(j); d1=(x(j)-lb(j))/span;
    d2=(ub(j)-x(j))/span; u=rand; exponent=1/(eta+1);
    if u<=0.5
        value=2*u+(1-2*u)*(1-d1)^(eta+1);
        delta=value^exponent-1;
    else
        value=2*(1-u)+2*(u-0.5)*(1-d2)^(eta+1);
        delta=1-value^exponent;
    end
    y(j)=min(ub(j),max(lb(j),x(j)+delta*span));
end
end
