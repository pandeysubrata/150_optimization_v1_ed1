function [z,fz,step]=cbLine(fun,x,f,g,d,lb,ub)
% Projected Armijo safeguard; clipping is a declared bounded adaptation.
step=1;
for k=1:40
 z=min(ub,max(lb,x+step*d)); fz=fun(z);
 if fz<=f+1e-4*g'*(z-x), return; end
 step=step/2;
end
z=x; fz=f; step=0;
end
