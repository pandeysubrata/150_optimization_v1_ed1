function o=cbOptions(o,lb,ub)
defaults=struct('maxIter',100,'popSize',30,'seed',1,'tolerance',1e-8, ...
 'display',false,'maxEval',20000,'alpha',0.05,'beta',0.9,'epsilon',1e-8, ...
 'F',0.7,'CR',0.9,'sigma',0.15,'memory',7,'rho',1,'lambda',0.1, ...
 'batchSize',8,'x0',lb+0.37*(ub-lb));
names=fieldnames(defaults);
for k=1:numel(names)
 if ~isfield(o,names{k}), o.(names{k})=defaults.(names{k}); end
end
o.x0=min(ub,max(lb,o.x0(:)));
assert(o.maxIter>=1 && o.maxIter==floor(o.maxIter));
assert(o.popSize>=6 && o.popSize==floor(o.popSize));
assert(o.maxEval>=1 && o.tolerance>0 && o.alpha>0);
end
