function H=cbHessian(fun,x,lb,ub,o)
if isfield(o,'hess'), H=o.hess(x); H=(H+H')/2; return; end
n=numel(x); H=zeros(n);
for j=1:n
 h=1e-4*max(1,abs(x(j))); a=x; b=x;
 a(j)=min(ub(j),x(j)+h); b(j)=max(lb(j),x(j)-h);
 H(:,j)=(cbGradient(fun,a,lb,ub,o)-cbGradient(fun,b,lb,ub,o))/(a(j)-b(j));
end
H=(H+H')/2;
end
