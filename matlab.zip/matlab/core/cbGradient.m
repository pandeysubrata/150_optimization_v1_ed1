function g=cbGradient(fun,x,lb,ub,o)
if isfield(o,'grad'), g=o.grad(x); g=g(:); return; end
g=zeros(size(x));
for j=1:numel(x)
 h=1e-6*max(1,abs(x(j))); a=x; b=x;
 a(j)=min(ub(j),x(j)+h); b(j)=max(lb(j),x(j)-h);
 g(j)=(fun(a)-fun(b))/(a(j)-b(j));
end
end
