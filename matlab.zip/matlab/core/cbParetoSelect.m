function [keep,rank,crowding]=cbParetoSelect(F,count,mode)
% Nondominated ranks, NSGA-II crowding, SPEA2/indicator/HV variants.
N=size(F,1); rank=zeros(N,1); remaining=true(N,1); level=1;
while any(remaining)
 ids=find(remaining); front=ids(cbNondominated(F(ids,:))); rank(front)=level; remaining(front)=false; level=level+1;
end
crowding=zeros(N,1);
for r=1:level-1
 ids=find(rank==r); m=numel(ids);
 for j=1:size(F,2)
  [values,order]=sort(F(ids,j)); crowding(ids(order([1 end])))=Inf;
  range=values(end)-values(1);
  if range>0 && m>2
   crowding(ids(order(2:end-1)))=crowding(ids(order(2:end-1)))+(values(3:end)-values(1:end-2))/range;
  end
 end
end
if strcmp(mode,'spea2')
 dominates=false(N);
 for i=1:N, for j=1:N, dominates(i,j)=all(F(i,:)<=F(j,:)) && any(F(i,:)<F(j,:)); end, end
 strength=sum(dominates,2); raw=dominates'*strength;
 scaled=(F-min(F,[],1))./max(max(F,[],1)-min(F,[],1),1e-12);
 D=sqrt(max(0,sum(scaled.^2,2)+sum(scaled.^2,2)'-2*scaled*scaled')); D(1:N+1:end)=Inf;
 ordered=sort(D,2); kth=max(1,floor(sqrt(N))); fitness=raw+1./(ordered(:,kth)+2);
 keep=find(fitness<1);
 if numel(keep)<count, [~,order]=sort(fitness); keep=order(1:count);
 else
  while numel(keep)>count
   distances=sort(D(keep,keep),2); [~,order]=sortrows(distances); keep(order(1))=[];
  end
 end
elseif strcmp(mode,'ibea')
 scaled=(F-min(F,[],1))./max(max(F,[],1)-min(F,[],1),1e-12); I=zeros(N);
 for i=1:N, for j=1:N, I(i,j)=max(scaled(i,:)-scaled(j,:)); end, end
 scale=max(abs(I(:))); scale=max(scale,1e-12); contribution=exp(-I/(0.05*scale)); contribution(1:N+1:end)=0;
 keep=(1:N)';
 while numel(keep)>count
  fitness=-sum(contribution(keep,keep),1); [~,worst]=min(fitness); keep(worst)=[];
 end
elseif strcmp(mode,'sms_emoa')
 assert(size(F,2)==2,'Exact hypervolume deletion here requires two objectives.'); keep=(1:N)';
 reference=max(F,[],1)+0.1*max(1,max(F,[],1)-min(F,[],1));
 while numel(keep)>count
  worstRank=max(rank(keep)); candidates=keep(rank(keep)==worstRank); contribution=zeros(numel(candidates),1);
  front=F(candidates,:); total=hypervolume(front,reference);
  for j=1:numel(candidates), subset=front; subset(j,:)=[]; contribution(j)=total-hypervolume(subset,reference); end
  [~,j]=min(contribution); keep(keep==candidates(j))=[];
 end
elseif strcmp(mode,'nsga3')
 % Reference-direction niching, with explicit ideal/nadir range normalization.
 M=size(F,2); assert(M==2,'This compact NSGA-III recipe uses two objectives.');
 weights=[linspace(0,1,count)' linspace(1,0,count)']; weights=weights./sqrt(sum(weights.^2,2));
 normalized=(F-min(F,[],1))./max(max(F,[],1)-min(F,[],1),1e-12);
 distance=zeros(N,count);
 for j=1:count, projection=normalized*weights(j,:)'; distance(:,j)=sqrt(max(0,sum(normalized.^2,2)-projection.^2)); end
 [nearest,association]=min(distance,[],2); keep=[]; r=1;
 while numel(keep)+sum(rank==r)<=count, keep=[keep;find(rank==r)]; r=r+1; end %#ok<AGROW>
 candidates=find(rank==r); occupancy=accumarray(association(keep),1,[count 1]);
 while numel(keep)<count && ~isempty(candidates)
  available=unique(association(candidates)); [~,q]=min(occupancy(available)); direction=available(q); ids=candidates(association(candidates)==direction);
  if occupancy(direction)==0, [~,q]=min(nearest(ids)); else, q=randi(numel(ids)); end
  selected=ids(q); keep(end+1,1)=selected; candidates(candidates==selected)=[]; occupancy(direction)=occupancy(direction)+1;
 end
else
 [~,order]=sortrows([rank -crowding],[1 2]); keep=order(1:count);
end
end
function hv=hypervolume(F,r)
if isempty(F), hv=0; return; end
F=F(cbNondominated(F),:); F=sortrows(F,1); top=r(2); hv=0;
for i=1:size(F,1)
 if F(i,2)<top, hv=hv+max(0,r(1)-F(i,1))*(top-F(i,2)); top=F(i,2); end
end
end
