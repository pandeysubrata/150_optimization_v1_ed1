function [c,d]=cbSBX(a,b,lb,ub,eta)
% Bounded simulated-binary crossover. Fixed coordinates remain fixed.
c=a; d=b;
if rand>0.9, return; end
for j=1:numel(a)
    if rand>0.5 || abs(a(j)-b(j))<1e-14 || ub(j)<=lb(j)
        continue;
    end
    y1=min(a(j),b(j)); y2=max(a(j),b(j)); u=rand;
    beta=1+2*(y1-lb(j))/(y2-y1); alpha=2-beta^(-eta-1);
    if u<=1/alpha, q=(u*alpha)^(1/(eta+1));
    else, q=(1/(2-u*alpha))^(1/(eta+1)); end
    c(j)=0.5*((y1+y2)-q*(y2-y1));
    beta=1+2*(ub(j)-y2)/(y2-y1); alpha=2-beta^(-eta-1);
    if u<=1/alpha, q=(u*alpha)^(1/(eta+1));
    else, q=(1/(2-u*alpha))^(1/(eta+1)); end
    d(j)=0.5*((y1+y2)+q*(y2-y1));
    if rand<0.5, t=c(j); c(j)=d(j); d(j)=t; end
end
c=min(ub,max(lb,c)); d=min(ub,max(lb,d));
end
