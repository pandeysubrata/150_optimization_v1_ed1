function [x,extra]=cbCMA(fun,lb,ub,o,mark)
n=numel(lb); lambda=o.popSize; mu=floor(lambda/2); weights=log(mu+0.5)-log((1:mu)'); weights=weights/sum(weights);
mueff=1/sum(weights.^2); cc=(4+mueff/n)/(n+4+2*mueff/n);
cs=(mueff+2)/(n+mueff+5); c1=2/((n+1.3)^2+mueff);
cmu=min(1-c1,2*(mueff-2+1/mueff)/((n+2)^2+mueff));
damping=1+2*max(0,sqrt((mueff-1)/(n+1))-1)+cs;
chi=sqrt(n)*(1-1/(4*n)+1/(21*n^2)); meanPoint=(o.x0-lb)./(ub-lb);
sigma=o.sigma; C=eye(n); pc=zeros(n,1); ps=pc; x=o.x0;
for k=1:o.maxIter
 C=(C+C')/2; [B,D]=eig(C); eigen=max(diag(D),1e-14); root=B*diag(sqrt(eigen)); invroot=B*diag(1./sqrt(eigen))*B';
 Z=randn(n,lambda); Y=root*Z; X=meanPoint+sigma*Y;
 % Reflection repairs the box; repaired displacements drive adaptation.
 X=1-abs(mod(X,2)-1); Y=(X-meanPoint)/sigma; values=zeros(lambda,1);
 for j=1:lambda, values(j)=fun(lb+(ub-lb).*X(:,j)); end
 [~,order]=sort(values); old=meanPoint; meanPoint=X(:,order(1:mu))*weights;
 step=(meanPoint-old)/sigma; ps=(1-cs)*ps+sqrt(cs*(2-cs)*mueff)*invroot*step;
 hsig=norm(ps)/sqrt(1-(1-cs)^(2*k))/chi<1.4+2/(n+1);
 pc=(1-cc)*pc+hsig*sqrt(cc*(2-cc)*mueff)*step;
 selected=Y(:,order(1:mu));
 C=(1-c1-cmu)*C+c1*(pc*pc'+(1-hsig)*cc*(2-cc)*C)+cmu*selected*diag(weights)*selected';
 sigma=sigma*exp(cs/damping*(norm(ps)/chi-1));
 x=lb+(ub-lb).*X(:,order(1)); mark();
 if sigma*sqrt(max(eigen))*max(ub-lb)<o.tolerance, break; end
end
extra=struct('stop','CMA generation or scale limit','sigma',sigma,'covariance',C, ...
 'variant','Full covariance update with explicit reflected-box adaptation');
end
