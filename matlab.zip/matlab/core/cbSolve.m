function [xBest,fBest,history]=cbSolve(name,fun,lb,ub,options)
% Instrumented interface. Feasible incumbents only; callbacks counted separately.
if nargin<5, options=struct(); end
lb=lb(:); ub=ub(:); assert(numel(lb)==numel(ub) && all(isfinite(lb)) && all(isfinite(ub)) && all(lb<ub));
o=cbOptions(options,lb,ub); rng(o.seed,'twister'); started=tic;
nEval=0; incumbent=Inf; incumbentX=[]; bestTrace=[]; evalTrace=[]; timeTrace=[];
oracles=struct('gradient',0,'hessian',0,'hessianVector',0,'sampleGradient',0,'residual',0);
if isfield(o,'grad'), originalGrad=o.grad; o.grad=@gradient; end
if isfield(o,'hess'), originalHess=o.hess; o.hess=@hessian; end
if isfield(o,'hessvec'), originalHV=o.hessvec; o.hessvec=@hessianVector; end
if isfield(o,'sampleGrad'), originalSample=o.sampleGrad; o.sampleGrad=@sample; end
if isfield(o,'residual'), originalResidual=o.residual; o.residual=@residual; end
multi=isfield(o,'multi') && o.multi; archiveX=[]; archiveF=[];
try
 [candidate,extra]=o.kernel(@objective,lb,ub,o,@checkpoint);
catch err
 if strcmp(err.identifier,'cookbook:budget')
  candidate=incumbentX; extra=struct('stop','evaluation budget');
 else, rethrow(err); end
end
if multi
 xBest=archiveX; fBest=archiveF;
else
 if isempty(incumbentX) && ~isempty(candidate) && nEval<o.maxEval, objective(candidate); end
 xBest=incumbentX; fBest=incumbent;
end
checkpoint(); history=struct('best',bestTrace,'evaluations',evalTrace, ...
 'runtime',timeTrace,'totalEvaluations',nEval,'seconds',toc(started), ...
 'seed',o.seed,'algorithm',name,'details',extra,'oracleCalls',oracles, ...
 'feasibleFound',~isempty(xBest));
if multi, history.best=[]; history.archiveX=xBest; history.archiveF=fBest; end
if o.display, fprintf('%s: %d objective calls, %.4g seconds\n',name,nEval,history.seconds); end
 function f=objective(x)
  if nEval>=o.maxEval,error('cookbook:budget','Evaluation budget reached.');end
  x=x(:);assert(numel(x)==numel(lb) && all(isfinite(x)),'Invalid candidate.');
  nEval=nEval+1; f=fun(x);assert(isnumeric(f) && isreal(f) && all(isfinite(f(:))),'Objective must return finite real values.');
  feasible=all(x>=lb-1e-8 & x<=ub+1e-8);
  if isfield(o,'feasible'), feasible=feasible && o.feasible(x); end
  if multi
   f=f(:)';
   if feasible
    archiveX=[archiveX x];archiveF=[archiveF;f];keep=cbNondominated(archiveF);archiveX=archiveX(:,keep);archiveF=archiveF(keep,:);
    [~,uniqueRows]=unique(archiveF,'rows','stable');archiveX=archiveX(:,uniqueRows);archiveF=archiveF(uniqueRows,:);
   end
  else
   assert(isscalar(f),'Scalar method received a vector objective.');
   if feasible && f<incumbent,incumbent=f;incumbentX=x;end
  end
 end
 function checkpoint()
  bestTrace(end+1,1)=incumbent;evalTrace(end+1,1)=nEval;timeTrace(end+1,1)=toc(started);
 end
 function g=gradient(x),oracles.gradient=oracles.gradient+1;g=originalGrad(x);end
 function H=hessian(x),oracles.hessian=oracles.hessian+1;H=originalHess(x);end
 function y=hessianVector(x,v),oracles.hessianVector=oracles.hessianVector+1;y=originalHV(x,v);end
 function g=sample(x,i),oracles.sampleGradient=oracles.sampleGradient+1;g=originalSample(x,i);end
 function r=residual(x),oracles.residual=oracles.residual+1;r=originalResidual(x);end
end
