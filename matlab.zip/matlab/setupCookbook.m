function setupCookbook
root=fileparts(mfilename('fullpath')); addpath(genpath(root));
fprintf('Cookbook paths added. Run demo_gradient_descent or runTests.\n');
end
