function [fun,lb,ub,o,reference]=makeProblem(name,variant)
% Deterministic schema examples; variant 1/2 changes data, not algorithm.
% Reference targets below are analytic or exhaustive, not measured run results.
if nargin<2,variant=1;end
n=3;target=[.3;-.4;.7]+.1*(variant-1); weights=[1;2;4];
lb=-3*ones(n,1);ub=3*ones(n,1);
fun=@(x) sum(weights.*(x-target).^2);
o=struct('maxIter',120,'maxEval',10000,'popSize',20,'seed',variant,'alpha',.1,'lambda',.1,'x0',zeros(n,1));
o.grad=@(x) 2*weights.*(x-target);o.hess=@(x) 2*diag(weights);
reference=struct('target',0,'kind','analytic minimum','name','weighted quadratic','note','Target is not a promised finite-budget outcome.');
if strcmp(name,'levenberg_marquardt'),o.residual=@(x)sqrt(weights).*(x-target);o.jacobian=@(x)diag(sqrt(weights));end
if any(strcmp(name,{'golden_section','brent'}))
 lb=-3;ub=3;o.x0=0;fun=@(x)(x-.4*variant).^2;o.grad=@(x)2*(x-.4*variant);o.hess=@(x)2;
end
if any(strcmp(name,{'proximal_gradient','fista','admm','chambolle_pock'}))
 b=[1;-.6;.2]*variant;lambda=.1;o.lambda=lambda;o.alpha=.8;
 fun=@(x).5*sum((x-b).^2)+lambda*sum(abs(x));o.grad=@(x)x-b;o.hess=@(x)eye(3);
 o.prox=@(z,t)sign(z).*max(abs(z)-t*lambda,0);o.problem=struct('A',eye(3),'D',eye(3),'b',b);
 star=sign(b).*max(abs(b)-lambda,0);reference.target=fun(star);reference.name='identity lasso';
end
if any(strcmp(name,{'frank_wolfe','away_frank_wolfe','mirror_descent'}))
 target=[.2;.3;.5];lb=zeros(3,1);ub=ones(3,1);o.x0=ones(3,1)/3;
 fun=@(x)sum((x-target).^2);o.grad=@(x)2*(x-target);o.hess=@(x)2*eye(3);o.feasible=@(x)abs(sum(x)-1)<1e-6;reference.name='simplex quadratic';
end
if any(strcmp(name,{'dual_ascent','augmented_lagrangian','sqp'}))
 fun=@(x).5*sum(x.^2);o.grad=@(x)x;o.hess=@(x)eye(3);o.x0=ones(3,1)/3;
 o.equalities=@(x)sum(x)-1;o.constraintJac=@(x)ones(1,3);o.feasible=@(x)abs(sum(x)-1)<1e-5;
 o.problem=struct('Q',eye(3),'c',zeros(3,1),'A',ones(1,3),'b',1);reference.target=1/6;reference.name='equality quadratic';
end
if any(strcmp(name,{'log_barrier','cobyla'}))
 lb=zeros(2,1);ub=2*ones(2,1);o.x0=[.1;.1];o.problem=struct('A',[1 1],'b',1);
 fun=@(x)sum((x-1).^2);o.grad=@(x)2*(x-1);o.hess=@(x)2*eye(2);
 o.inequalities=@(x)sum(x)-1;o.feasible=@(x)sum(x)<=1+1e-6;reference.target=.5;reference.name='triangle constrained quadratic';
end
if strcmp(name,'simplex_lp')
 lb=zeros(2,1);ub=10*ones(2,1);o.x0=zeros(2,1);o.problem=struct('A',[1 1;1 0;0 1],'b',[4;2;3],'c',[-3;-2]);
 fun=@(x)[-3 -2]*x;o.feasible=@(x)all(o.problem.A*x<=o.problem.b+1e-6);reference.target=-10;reference.name='slack-feasible LP';
elseif strcmp(name,'primal_dual_ip')
 lb=zeros(2,1);ub=3*ones(2,1);o.x0=ones(2,1);o.problem=struct('A',[1 1],'b',1,'c',[1;2]);fun=@(x)[1 2]*x;
 o.feasible=@(x)abs(sum(x)-1)<1e-5;reference.target=1;reference.name='standard-form LP';
end
binary={'binary_ga','umda','pbil','compact_ga'};
if any(strcmp(name,binary))
 lb=zeros(8,1);ub=ones(8,1);o.x0=zeros(8,1);fun=@(x)sum(1-x);o.feasible=@(x)all(x==0|x==1);reference.name='OneMax as minimization';
end
knapsack={'branch_bound','knapsack_dp','subset_sum_dp'};
if any(strcmp(name,knapsack))
 w=[2;3;4;5];v=[3;4;5;8];cap=7+variant-1;if strcmp(name,'subset_sum_dp'),v=w;end
 lb=zeros(4,1);ub=ones(4,1);o.x0=lb;o.maxIter=1000;o.problem=struct('weights',w,'values',v,'capacity',cap);
 fun=@(x)-v'*x;o.feasible=@(x)all(x==0|x==1) && w'*x<=cap;
 B=dec2bin(0:15)-'0';valid=B*w<=cap;reference.target=min(-B(valid,:)*v);reference.name='four-item knapsack';
end
if strcmp(name,'hungarian')
 cost=[4 1 3;2 0 5;3 2 2]+variant-1;lb=ones(3,1);ub=3*ones(3,1);o.x0=lb;o.problem=struct('cost',cost);fun=@(x)sum(cost(sub2ind(size(cost),(1:3)',round(x))));
 o.feasible=@(x)numel(unique(x))==3 && all(x==round(x));P=perms(1:3);values=zeros(size(P,1),1);for i=1:size(P,1),values(i)=fun(P(i,:)');end
 reference.target=min(values);reference.name='three-worker assignment';
end
pathNames={'dijkstra','bellman_ford','floyd_warshall','astar','prim','kruskal','edmonds_karp'};
localNames={'simulated_annealing','threshold_accepting','record_to_record','tabu','ils','vns','grasp','guided_local','late_acceptance','iterated_greedy'};
antNames={'ant_system','ant_colony_system','maxmin_ant'};
tourNames=[{'held_karp','two_opt','farthest_insertion','double_tree'} localNames antNames];
if any(strcmp(name,[pathNames tourNames]))
 points=[0 0;1 0;2 .4;1.7 1.5;.7 1.8;-.3 1]*variant;W=zeros(6);
 for i=1:6,for j=1:6,W(i,j)=norm(points(i,:)-points(j,:));end,end
 o.problem=struct('graph',W,'source',1,'target',6,'heuristic',zeros(6,1));
 lb=zeros(6,1);ub=6*ones(6,1);o.x0=ones(6,1);reference.name='six-node Euclidean graph';
 if any(strcmp(name,tourNames))
  lb=ones(6,1);fun=@(x)tourValue(x,W);o.feasible=@(x)isequal(sort(x),(1:6)');P=perms(2:6);val=zeros(size(P,1),1);
  for i=1:size(P,1),val(i)=fun([1 P(i,:)]');end;reference.target=min(val);
 elseif strcmp(name,'edmonds_karp')
  C=[0 3 2 0 0 0;0 0 1 3 0 0;0 0 0 1 2 0;0 0 0 0 1 3;0 0 0 0 0 3;0 0 0 0 0 0]*variant;
  o.problem.capacityMatrix=C;ub=20*ones(6,1);fun=@(x)-x(1);reference.target=-5*variant;
 elseif strcmp(name,'floyd_warshall')
  ub=20*ones(6,1);fun=@(x)sum((x-W(1,:)').^2);reference.target=0;
 else
  fun=@(x)parentValue(x,W,any(strcmp(name,{'prim','kruskal'})));
  if any(strcmp(name,{'prim','kruskal'})),reference.target=NaN;reference.note='Check tree edges and compare Prim versus Kruskal; target not precomputed.';
  else,reference.target=sum(W(1,:));end
 end
end
mlNames={'sgd','minibatch_sgd','adagrad','rmsprop','adadelta','adam','adamw','adamax','nadam','amsgrad','svrg','saga','sarah'};
if any(strcmp(name,mlNames))
 data=[target-.1 target target+.1 target];o.numSamples=4;o.sampleGrad=@(x,i)2*(x-data(:,i));o.alpha=.05;o.lambda=0;
 fun=@(x)mean(sum((x-data).^2,1));o.grad=@(x)2*(x-mean(data,2));reference.target=fun(mean(data,2));reference.name='finite-sum quadratic';
end
multiNames={'weighted_sum','epsilon_constraint','nsga2','spea2','moead','mopso','paes','nsga3','ibea','sms_emoa'};
if any(strcmp(name,multiNames))
 lb=zeros(2,1);ub=ones(2,1);o.x0=[.5;.5];fun=@(x)[x(1)^2+x(2)^2 (x(1)-1)^2+x(2)^2];o.multi=true;
 o.epsilonLevels=linspace(0,1,o.popSize);reference.target=NaN;reference.name='two-objective parabola front';reference.note='Pareto set x2=0, x1 in [0,1]; output is an archive, not one optimum.';
end
if any(strcmp(name,{'saa','minimax_subgradient','cvar'}))
 S=[-1 0 1;0 0 0]*variant;o.scenarios=S;o.alpha=.15;lb=-4*ones(2,1);ub=4*ones(2,1);o.x0=ones(2,1);
 if strcmp(name,'saa'),fun=@(x)mean(sum((x-S).^2,1));reference.target=2*variant^2/3;
 elseif strcmp(name,'minimax_subgradient'),fun=@(x)max(sum((x-S).^2,1));reference.target=variant^2;
 else,lb=[lb;0];ub=[ub;20];o.x0=[1;1;1];o.confidence=.8;fun=@(x)x(end)+mean(max(0,sum((x(1:2)-S).^2,1)-x(end)))/(1-o.confidence);reference.target=variant^2;end
 reference.name='three-scenario quadratic risk';
end
if any(strcmp(name,{'progressive_hedging','consensus_admm','distributed_gradient','extra','gradient_tracking'}))
 centers=[-1 0 1;.5 0 -.5]*variant;lb=-4*ones(2,1);ub=4*ones(2,1);o.x0=[1;1];o.centers=centers;o.mixing=.5*eye(3)+ones(3)/6;o.alpha=.1;
 fun=@(x).5*mean(sum((x-centers).^2,1));reference.target=fun(mean(centers,2));reference.name='quadratic consensus';
end
if any(strcmp(name,{'ilqr','mpc'}))
 o.A=.9;o.B=.2;o.Q=1;o.R=.1;o.Qf=2;o.horizon=12;o.initialState=variant;lb=-2*ones(12,1);ub=2*ones(12,1);o.x0=zeros(12,1);fun=@(x)controlCost(x,o);
 reference.target=NaN;reference.name='finite-horizon scalar control';reference.note='Compare cost to zero input; unconstrained Riccati target may violate input bounds.';
end
% Analytic derivatives are only supplied for smooth schemas where valid.
if ~any(strcmp(name,{'gradient_descent','heavy_ball','nesterov','newton','damped_newton','bfgs','dfp','lbfgs','sr1','cg_fr','cg_pr','cg_hs','cg_dy','levenberg_marquardt','dogleg','projected_gradient','proximal_gradient','fista','frank_wolfe','away_frank_wolfe','mirror_descent','ellipsoid','log_barrier','sqp','augmented_lagrangian','lookahead','memetic_ga','basin_hopping'}))
 o=rmfield(o,intersect(fieldnames(o),{'grad','hess'}));
end
if any(strcmp(name,{'coordinate_descent','gauss_newton','truncated_newton'}))
 o.grad=@(x)2*weights.*(x-target);o.hess=@(x)2*diag(weights);
 o.hessvec=@(x,v)2*weights.*v;
 o.residual=@(x)sqrt(weights).*(x-target);
 o.jacobian=@(x)diag(sqrt(weights));
 if strcmp(name,'gauss_newton'),fun=@(x).5*sum(weights.*(x-target).^2);o.grad=@(x)weights.*(x-target);end
end
if any(strcmp(name,{'lion','adafactor','shampoo'}))
 target=[.3;-.4;.7;-.2]+.1*(variant-1);data=[target-.1 target target+.1 target];
 lb=-3*ones(4,1);ub=3*ones(4,1);o.x0=zeros(4,1);o.matrixShape=[2 2];
 o.numSamples=4;o.sampleGrad=@(x,i)2*(x-data(:,i));o.lambda=0;o.alpha=.02;
 fun=@(x)mean(sum((x-data).^2,1));reference.target=fun(mean(data,2));
 reference.name='four-parameter matrix finite sum';
end
end
function f=tourValue(x,W)
x=round(x(:));f=0;for j=1:numel(x),f=f+W(x(j),x(mod(j,numel(x))+1));end
end
function f=parentValue(x,W,tree)
x=round(x(:));N=numel(x);f=0;
for j=2:N
 if tree,if x(j)<1,f=f+1e6;else,f=f+W(j,x(j));end
 else
  current=j;seen=false(N,1);
  while current~=1
   if current<1 || seen(current) || x(current)<1,f=f+1e6;break;end
   seen(current)=true;f=f+W(current,x(current));current=x(current);
  end
 end
end
end
function f=controlCost(u,o)
s=o.initialState;f=0;for t=1:o.horizon,f=f+s'*o.Q*s+u(t)'*o.R*u(t);s=o.A*s+o.B*u(t);end;f=f+s'*o.Qf*s;
end
