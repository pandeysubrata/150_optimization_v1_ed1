function results=runBenchmarkResume(methods,seeds,checkpoint)
% Resume at completed-run boundaries. A checkpoint has an exact configuration.
if nargin<1, methods={'de_rand1','pso','nelder_mead'}; end
if nargin<2, seeds=1:10; end
if nargin<3, checkpoint='benchmark-resume.mat'; end
config=struct('methods',{methods},'seeds',seeds,'dimension',5, ...
    'maxEval',5000,'maxIter',500,'popSize',30);
results=struct([]);
if exist(checkpoint,'file')==2
    saved=load(checkpoint,'config','results');
    assert(isequal(saved.config,config),'Checkpoint configuration differs.');
    results=saved.results;
end
problems={'sphere','rastrigin','rosenbrock','ackley'};
for p=1:numel(problems)
    [fun,lb,ub,star]=benchmarkFunctions(problems{p},config.dimension);
    for a=1:numel(methods)
        for seed=seeds
            if ~isempty(results)
                done=strcmp({results.problem},problems{p}) & ...
                    strcmp({results.method},methods{a}) & [results.seed]==seed;
                if any(done), continue; end % Retain failures; do not reroll them.
            end
            row=struct('problem',problems{p},'method',methods{a}, ...
                'seed',seed,'value',NaN,'gap',NaN,'evaluations',0, ...
                'seconds',NaN,'status','failed');
            try
                o=struct('seed',seed,'maxEval',config.maxEval, ...
                    'maxIter',config.maxIter,'popSize',config.popSize);
                [~,f,h]=feval(methods{a},fun,lb,ub,o);
                row.value=f; row.gap=f-fun(star);
                row.evaluations=h.totalEvaluations; row.seconds=h.seconds;
                row.status='completed';
                save(sprintf('%s_%s_%d.mat',problems{p},methods{a},seed),'h');
            catch err
                row.status=err.message;
            end
            results(end+1)=row; %#ok<AGROW>
            temporary=[checkpoint '.temporary'];
            save(temporary,'config','results','-mat');
            movefile(temporary,checkpoint,'f');
        end
    end
end
writetable(struct2table(results),'benchmark-results.csv');
summarizeBenchmark(results);
end
