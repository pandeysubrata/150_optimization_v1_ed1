function results=runBenchmark(methods,seeds)
% Compare ONLY compatible continuous scalar derivative-free/population solvers.
% Repeat seeds, report failures and objective calls. No hidden discarded runs.
if nargin<1,methods={'de_rand1','pso','nelder_mead'};end
if nargin<2,seeds=1:10;end
problems={'sphere','rastrigin','rosenbrock','ackley'};results=struct([]);q=0;
for p=1:numel(problems)
 [fun,lb,ub,star]=benchmarkFunctions(problems{p},5);
 for a=1:numel(methods)
  for seed=seeds
   q=q+1;r=struct('problem',problems{p},'method',methods{a},'seed',seed,'value',NaN,'gap',NaN,'evaluations',0,'seconds',NaN,'status','failed');
   try
    o=struct('seed',seed,'maxEval',5000,'maxIter',500,'popSize',30);[~,f,h]=feval(methods{a},fun,lb,ub,o);
    r.value=f;r.gap=f-fun(star);r.evaluations=h.totalEvaluations;r.seconds=h.seconds;r.status='completed';
    traceName=sprintf('%s_%s_%d.mat',problems{p},methods{a},seed);save(traceName,'h');
   catch err,r.status=err.message;end
   results(q)=r;save('benchmark-checkpoint.mat','results');
  end
 end
end
writetable(struct2table(results),'benchmark-results.csv');
end
