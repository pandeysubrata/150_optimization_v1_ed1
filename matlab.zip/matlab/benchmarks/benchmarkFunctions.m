function [fun,lb,ub,star]=benchmarkFunctions(name,n)
% Standard unconstrained functions: minima are known analytically.
if nargin<2,n=5;end
switch lower(name)
 case 'sphere',fun=@(x)sum(x.^2);b=5.12;star=zeros(n,1);
 case 'rastrigin',fun=@(x)10*n+sum(x.^2-10*cos(2*pi*x));b=5.12;star=zeros(n,1);
 case 'rosenbrock',fun=@(x)sum(100*(x(2:end)-x(1:end-1).^2).^2+(1-x(1:end-1)).^2);b=3;star=ones(n,1);
 case 'ackley',fun=@(x)-20*exp(-.2*sqrt(mean(x.^2)))-exp(mean(cos(2*pi*x)))+20+exp(1);b=5;star=zeros(n,1);
 otherwise,error('Unknown benchmark');
end
lb=-b*ones(n,1);ub=b*ones(n,1);
end
