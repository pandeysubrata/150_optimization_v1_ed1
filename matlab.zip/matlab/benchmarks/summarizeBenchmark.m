function summary=summarizeBenchmark(results)
% Summarize every run, including failures; no toolbox statistics functions.
if nargin<1
    loaded=load('benchmark-checkpoint.mat','results'); results=loaded.results;
end
problems=unique({results.problem},'stable');
methods=unique({results.method},'stable'); summary=struct([]); q=0;
for p=1:numel(problems)
    figure('Name',problems{p}); hold on; labels={};
    for a=1:numel(methods)
        ids=find(strcmp({results.problem},problems{p}) & ...
            strcmp({results.method},methods{a}));
        values=[results(ids).gap];
        good=isfinite(values) & strcmp({results(ids).status},'completed');
        q=q+1; summary(q).problem=problems{p};
        summary(q).method=methods{a}; summary(q).runs=numel(ids);
        summary(q).failures=sum(~good);
        if any(good)
            v=values(good); summary(q).medianGap=median(v);
            summary(q).meanGap=mean(v); summary(q).stdGap=std(v);
        else
            summary(q).medianGap=NaN; summary(q).meanGap=NaN;
            summary(q).stdGap=NaN;
        end
        % Plot original incumbent traces, aligned by objective evaluations.
        for j=ids
            name=sprintf('%s_%s_%d.mat',problems{p},methods{a},results(j).seed);
            if exist(name,'file')~=2, continue; end
            data=load(name,'h'); h=data.h;
            if isempty(h.best), continue; end
            plot(h.evaluations,h.best,'DisplayName', ...
                sprintf('%s seed %d',methods{a},results(j).seed));
        end
        labels{end+1}=methods{a}; %#ok<AGROW>
    end
    xlabel('Objective evaluations'); ylabel('Feasible best objective');
    title(problems{p},'Interpreter','none'); grid on;
    legend('show','Interpreter','none','Location','best');
    saveas(gcf,[problems{p} '-convergence.png']);
end
writetable(struct2table(summary),'benchmark-summary.csv');
end
