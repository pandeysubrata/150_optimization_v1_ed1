% Recipe 126: Multi-objective PSO
% Run setupCookbook from matlab/ first. No toolbox dependency.
[fun,lb,ub,options,reference]=makeProblem('mopso',1);
[xBest,fBest,history]=mopso(fun,lb,ub,options);
disp(reference); disp(fBest);
plot(fBest(:,1),fBest(:,2),'o'); xlabel('f_1'); ylabel('f_2');
grid on;
