% Repeated input-constrained horizon solves, warm start and first-move execution.
[~,lb,ub,o]=makeProblem('mpc',1);state=o.initialState;trajectory=state;
for t=1:25
 o.initialState=state;fun=@(u)stageCost(u,o);[u,~,h]=mpc(fun,lb,ub,o);
 assert(~isempty(u),'No feasible control plan');state=o.A*state+o.B*u(1);trajectory(end+1)=state;
 o.x0=[u(2:end);u(end)];
end
plot(0:25,trajectory);xlabel('Sample');ylabel('State');grid on;
function f=stageCost(u,o)
s=o.initialState;f=0;for k=1:o.horizon,f=f+o.Q*s^2+o.R*u(k)^2;s=o.A*s+o.B*u(k);end;f=f+o.Qf*s^2;
end
