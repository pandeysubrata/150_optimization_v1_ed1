[fun,lb,ub,o,reference]=makeProblem('adafactor',1);
[x,f,h]=adafactor(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
