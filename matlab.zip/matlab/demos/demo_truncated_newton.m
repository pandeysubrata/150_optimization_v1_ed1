[fun,lb,ub,o,reference]=makeProblem('truncated_newton',1);
[x,f,h]=truncated_newton(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
