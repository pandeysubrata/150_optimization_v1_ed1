% Recipe 122: Epsilon-constraint method
% Run setupCookbook from matlab/ first. No toolbox dependency.
[fun,lb,ub,options,reference]=makeProblem('epsilon_constraint',1);
[xBest,fBest,history]=epsilon_constraint(fun,lb,ub,options);
disp(reference); disp(fBest);
plot(fBest(:,1),fBest(:,2),'o'); xlabel('f_1'); ylabel('f_2');
grid on;
