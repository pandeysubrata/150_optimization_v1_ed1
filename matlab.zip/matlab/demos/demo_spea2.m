% Recipe 124: SPEA2
% Run setupCookbook from matlab/ first. No toolbox dependency.
[fun,lb,ub,options,reference]=makeProblem('spea2',1);
[xBest,fBest,history]=spea2(fun,lb,ub,options);
disp(reference); disp(fBest);
plot(fBest(:,1),fBest(:,2),'o'); xlabel('f_1'); ylabel('f_2');
grid on;
