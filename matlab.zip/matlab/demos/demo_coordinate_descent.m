[fun,lb,ub,o,reference]=makeProblem('coordinate_descent',1);
[x,f,h]=coordinate_descent(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
