[fun,lb,ub,o,reference]=makeProblem('gauss_newton',1);
[x,f,h]=gauss_newton(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
