% Recipe 097: Firefly algorithm
% Run setupCookbook from matlab/ first. No toolbox dependency.
[fun,lb,ub,options,reference]=makeProblem('firefly',1);
[xBest,fBest,history]=firefly(fun,lb,ub,options);
disp(reference); disp(fBest);
plot(history.evaluations,history.best,'LineWidth',1.4);
xlabel('Objective evaluations'); ylabel('Best feasible objective');
grid on;
