% Recipe 093: Ant System
% Run setupCookbook from matlab/ first. No toolbox dependency.
[fun,lb,ub,options,reference]=makeProblem('ant_system',1);
[xBest,fBest,history]=ant_system(fun,lb,ub,options);
disp(reference); disp(fBest);
plot(history.evaluations,history.best,'LineWidth',1.4);
xlabel('Objective evaluations'); ylabel('Best feasible objective');
grid on;
