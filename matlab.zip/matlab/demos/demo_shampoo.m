[fun,lb,ub,o,reference]=makeProblem('shampoo',1);
[x,f,h]=shampoo(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
