[fun,lb,ub,o,reference]=makeProblem('lion',1);
[x,f,h]=lion(fun,lb,ub,o);
disp(reference);disp(f);
plot(h.evaluations,h.best);grid on;
