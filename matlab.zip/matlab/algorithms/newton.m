function [xBest,fBest,history]=newton(fun,lb,ub,options)
% Newton's method -- R004. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@newton_kernel;
[xBest,fBest,history]=cbSolve('newton',fun,lb,ub,options);
end
