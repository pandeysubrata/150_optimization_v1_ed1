function [xBest,fBest,history]=jaya(fun,lb,ub,options)
% Jaya algorithm -- R110. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@jaya_kernel;
[xBest,fBest,history]=cbSolve('jaya',fun,lb,ub,options);
end
