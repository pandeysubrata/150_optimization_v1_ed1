function [xBest,fBest,history]=nelder_mead(fun,lb,ub,options)
% Nelder-Mead -- R051. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@nelder_mead_kernel;
[xBest,fBest,history]=cbSolve('nelder_mead',fun,lb,ub,options);
end
