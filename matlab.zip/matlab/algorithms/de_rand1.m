function [xBest,fBest,history]=de_rand1(fun,lb,ub,options)
% DE/rand/1/bin -- R079. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@de_rand1_kernel;
[xBest,fBest,history]=cbSolve('de_rand1',fun,lb,ub,options);
end
