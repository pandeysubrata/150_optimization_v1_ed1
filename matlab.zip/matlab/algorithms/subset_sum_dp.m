function [xBest,fBest,history]=subset_sum_dp(fun,lb,ub,options)
% Subset-sum dynamic programming -- R048. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@subset_sum_dp_kernel;
[xBest,fBest,history]=cbSolve('subset_sum_dp',fun,lb,ub,options);
end
