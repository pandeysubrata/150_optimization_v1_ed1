function [xBest,fBest,history]=double_tree(fun,lb,ub,options)
% Double-tree metric TSP approximation -- R047. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@double_tree_kernel;
[xBest,fBest,history]=cbSolve('double_tree',fun,lb,ub,options);
end
