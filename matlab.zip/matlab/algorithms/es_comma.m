function [xBest,fBest,history]=es_comma(fun,lb,ub,options)
% Mu-comma-lambda evolution strategy -- R086. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@es_comma_kernel;
[xBest,fBest,history]=cbSolve('es_comma',fun,lb,ub,options);
end
