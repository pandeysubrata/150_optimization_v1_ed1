function [xBest,fBest,history]=guided_local(fun,lb,ub,options)
% Guided local search -- R118. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@guided_local_kernel;
[xBest,fBest,history]=cbSolve('guided_local',fun,lb,ub,options);
end
