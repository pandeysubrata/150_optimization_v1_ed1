function [xBest,fBest,history]=jde(fun,lb,ub,options)
% jDE -- R144. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@jde_kernel;
[xBest,fBest,history]=cbSolve('jde',fun,lb,ub,options);
end
