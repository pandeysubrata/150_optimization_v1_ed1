function [xBest,fBest,history]=minimax_subgradient(fun,lb,ub,options)
% Robust minimax subgradient -- R132. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@minimax_subgradient_kernel;
[xBest,fBest,history]=cbSolve('minimax_subgradient',fun,lb,ub,options);
end
