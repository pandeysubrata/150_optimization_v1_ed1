function [xBest,fBest,history]=nsga3(fun,lb,ub,options)
% NSGA-III -- R128. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@nsga3_kernel;
[xBest,fBest,history]=cbSolve('nsga3',fun,lb,ub,options);
end
