function [xBest,fBest,history]=rbf_search(fun,lb,ub,options)
% Radial-basis surrogate search -- R059. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@rbf_search_kernel;
[xBest,fBest,history]=cbSolve('rbf_search',fun,lb,ub,options);
end
