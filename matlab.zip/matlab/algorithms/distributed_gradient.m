function [xBest,fBest,history]=distributed_gradient(fun,lb,ub,options)
% Distributed gradient descent -- R136. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@distributed_gradient_kernel;
[xBest,fBest,history]=cbSolve('distributed_gradient',fun,lb,ub,options);
end
