function [xBest,fBest,history]=sarah(fun,lb,ub,options)
% SARAH -- R073. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@sarah_kernel;
[xBest,fBest,history]=cbSolve('sarah',fun,lb,ub,options);
end
