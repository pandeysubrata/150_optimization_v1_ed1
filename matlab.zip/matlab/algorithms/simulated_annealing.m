function [xBest,fBest,history]=simulated_annealing(fun,lb,ub,options)
% Simulated annealing -- R111. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@simulated_annealing_kernel;
[xBest,fBest,history]=cbSolve('simulated_annealing',fun,lb,ub,options);
end
