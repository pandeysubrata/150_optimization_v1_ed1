function [xBest,fBest,history]=mpc(fun,lb,ub,options)
% Receding-horizon MPC -- R140. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@mpc_kernel;
[xBest,fBest,history]=cbSolve('mpc',fun,lb,ub,options);
end
