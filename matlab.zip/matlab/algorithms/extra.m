function [xBest,fBest,history]=extra(fun,lb,ub,options)
% EXTRA -- R137. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@extra_kernel;
[xBest,fBest,history]=cbSolve('extra',fun,lb,ub,options);
end
