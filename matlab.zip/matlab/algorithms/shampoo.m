function [xBest,fBest,history]=shampoo(fun,lb,ub,options)
% Shampoo -- R076. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@shampoo_kernel;
[xBest,fBest,history]=cbSolve('shampoo',fun,lb,ub,options);
end
