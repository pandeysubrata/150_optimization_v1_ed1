function [xBest,fBest,history]=barebones_pso(fun,lb,ub,options)
% Bare-bones PSO -- R097. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@barebones_pso_kernel;
[xBest,fBest,history]=cbSolve('barebones_pso',fun,lb,ub,options);
end
