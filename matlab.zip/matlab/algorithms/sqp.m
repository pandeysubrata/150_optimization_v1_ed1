function [xBest,fBest,history]=sqp(fun,lb,ub,options)
% Equality-constrained SQP -- R027. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@sqp_kernel;
[xBest,fBest,history]=cbSolve('sqp',fun,lb,ub,options);
end
