function [xBest,fBest,history]=epsilon_constraint(fun,lb,ub,options)
% Epsilon-constraint method -- R122. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@epsilon_constraint_kernel;
[xBest,fBest,history]=cbSolve('epsilon_constraint',fun,lb,ub,options);
end
