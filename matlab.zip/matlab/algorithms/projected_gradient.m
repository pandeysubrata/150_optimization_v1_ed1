function [xBest,fBest,history]=projected_gradient(fun,lb,ub,options)
% Projected gradient -- R019. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@projected_gradient_kernel;
[xBest,fBest,history]=cbSolve('projected_gradient',fun,lb,ub,options);
end
