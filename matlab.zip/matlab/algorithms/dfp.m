function [xBest,fBest,history]=dfp(fun,lb,ub,options)
% Davidon-Fletcher-Powell -- R007. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@dfp_kernel;
[xBest,fBest,history]=cbSolve('dfp',fun,lb,ub,options);
end
