function [xBest,fBest,history]=ibea(fun,lb,ub,options)
% Indicator-based evolutionary algorithm -- R129. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@ibea_kernel;
[xBest,fBest,history]=cbSolve('ibea',fun,lb,ub,options);
end
