function [xBest,fBest,history]=lion(fun,lb,ub,options)
% Lion -- R074. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@lion_kernel;
[xBest,fBest,history]=cbSolve('lion',fun,lb,ub,options);
end
