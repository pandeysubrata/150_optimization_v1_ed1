function [xBest,fBest,history]=inertia_pso(fun,lb,ub,options)
% Inertia-weight PSO -- R093. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@inertia_pso_kernel;
[xBest,fBest,history]=cbSolve('inertia_pso',fun,lb,ub,options);
end
