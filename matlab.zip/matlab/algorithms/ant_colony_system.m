function [xBest,fBest,history]=ant_colony_system(fun,lb,ub,options)
% Ant Colony System -- R100. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ant_colony_system_kernel;
[xBest,fBest,history]=cbSolve('ant_colony_system',fun,lb,ub,options);
end
