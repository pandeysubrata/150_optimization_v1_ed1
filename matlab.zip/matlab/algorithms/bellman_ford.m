function [xBest,fBest,history]=bellman_ford(fun,lb,ub,options)
% Bellman-Ford shortest path -- R039. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@bellman_ford_kernel;
[xBest,fBest,history]=cbSolve('bellman_ford',fun,lb,ub,options);
end
