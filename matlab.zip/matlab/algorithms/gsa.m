function [xBest,fBest,history]=gsa(fun,lb,ub,options)
% Gravitational search algorithm -- R106. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@gsa_kernel;
[xBest,fBest,history]=cbSolve('gsa',fun,lb,ub,options);
end
