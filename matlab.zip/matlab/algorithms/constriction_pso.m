function [xBest,fBest,history]=constriction_pso(fun,lb,ub,options)
% Constriction PSO -- R094. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@constriction_pso_kernel;
[xBest,fBest,history]=cbSolve('constriction_pso',fun,lb,ub,options);
end
