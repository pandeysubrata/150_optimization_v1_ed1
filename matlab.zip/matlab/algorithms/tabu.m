function [xBest,fBest,history]=tabu(fun,lb,ub,options)
% Tabu search -- R114. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@tabu_kernel;
[xBest,fBest,history]=cbSolve('tabu',fun,lb,ub,options);
end
