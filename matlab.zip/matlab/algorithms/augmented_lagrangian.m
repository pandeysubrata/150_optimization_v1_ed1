function [xBest,fBest,history]=augmented_lagrangian(fun,lb,ub,options)
% Augmented Lagrangian -- R026. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@augmented_lagrangian_kernel;
[xBest,fBest,history]=cbSolve('augmented_lagrangian',fun,lb,ub,options);
end
