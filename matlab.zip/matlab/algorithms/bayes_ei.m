function [xBest,fBest,history]=bayes_ei(fun,lb,ub,options)
% Gaussian-process expected improvement -- R058. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@bayes_ei_kernel;
[xBest,fBest,history]=cbSolve('bayes_ei',fun,lb,ub,options);
end
