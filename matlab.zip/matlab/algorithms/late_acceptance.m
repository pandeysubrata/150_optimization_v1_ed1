function [xBest,fBest,history]=late_acceptance(fun,lb,ub,options)
% Late-acceptance hill climbing -- R119. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@late_acceptance_kernel;
[xBest,fBest,history]=cbSolve('late_acceptance',fun,lb,ub,options);
end
