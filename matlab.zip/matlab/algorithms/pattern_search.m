function [xBest,fBest,history]=pattern_search(fun,lb,ub,options)
% Generalized pattern search -- R054. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@pattern_search_kernel;
[xBest,fBest,history]=cbSolve('pattern_search',fun,lb,ub,options);
end
