function [xBest,fBest,history]=admm(fun,lb,ub,options)
% ADMM -- R024. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@admm_kernel;
[xBest,fBest,history]=cbSolve('admm',fun,lb,ub,options);
end
