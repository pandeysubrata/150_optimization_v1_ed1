function [xBest,fBest,history]=golden_section(fun,lb,ub,options)
% Golden-section search -- R049. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@golden_section_kernel;
[xBest,fBest,history]=cbSolve('golden_section',fun,lb,ub,options);
end
