function [xBest,fBest,history]=edmonds_karp(fun,lb,ub,options)
% Edmonds-Karp maximum flow -- R043. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@edmonds_karp_kernel;
[xBest,fBest,history]=cbSolve('edmonds_karp',fun,lb,ub,options);
end
