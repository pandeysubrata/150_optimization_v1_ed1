function [xBest,fBest,history]=minibatch_sgd(fun,lb,ub,options)
% Mini-batch SGD -- R062. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@minibatch_sgd_kernel;
[xBest,fBest,history]=cbSolve('minibatch_sgd',fun,lb,ub,options);
end
