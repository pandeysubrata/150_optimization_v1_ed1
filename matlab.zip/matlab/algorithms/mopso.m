function [xBest,fBest,history]=mopso(fun,lb,ub,options)
% Multi-objective PSO -- R126. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@mopso_kernel;
[xBest,fBest,history]=cbSolve('mopso',fun,lb,ub,options);
end
