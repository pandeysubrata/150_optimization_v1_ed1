function [xBest,fBest,history]=log_barrier(fun,lb,ub,options)
% Logarithmic barrier -- R028. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@log_barrier_kernel;
[xBest,fBest,history]=cbSolve('log_barrier',fun,lb,ub,options);
end
