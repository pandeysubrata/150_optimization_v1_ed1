function [xBest,fBest,history]=de_best1(fun,lb,ub,options)
% DE/best/1/bin -- R080. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@de_best1_kernel;
[xBest,fBest,history]=cbSolve('de_best1',fun,lb,ub,options);
end
