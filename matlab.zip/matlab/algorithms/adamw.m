function [xBest,fBest,history]=adamw(fun,lb,ub,options)
% AdamW -- R067. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adamw_kernel;
[xBest,fBest,history]=cbSolve('adamw',fun,lb,ub,options);
end
