function [xBest,fBest,history]=saga(fun,lb,ub,options)
% SAGA -- R072. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@saga_kernel;
[xBest,fBest,history]=cbSolve('saga',fun,lb,ub,options);
end
