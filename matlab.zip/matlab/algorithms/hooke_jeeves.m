function [xBest,fBest,history]=hooke_jeeves(fun,lb,ub,options)
% Hooke-Jeeves pattern search -- R053. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@hooke_jeeves_kernel;
[xBest,fBest,history]=cbSolve('hooke_jeeves',fun,lb,ub,options);
end
