function [xBest,fBest,history]=abc(fun,lb,ub,options)
% Artificial bee colony -- R102. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@abc_kernel;
[xBest,fBest,history]=cbSolve('abc',fun,lb,ub,options);
end
