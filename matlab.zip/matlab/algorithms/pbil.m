function [xBest,fBest,history]=pbil(fun,lb,ub,options)
% Population-based incremental learning -- R089. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@pbil_kernel;
[xBest,fBest,history]=cbSolve('pbil',fun,lb,ub,options);
end
