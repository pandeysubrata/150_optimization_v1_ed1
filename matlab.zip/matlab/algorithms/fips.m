function [xBest,fBest,history]=fips(fun,lb,ub,options)
% Fully informed particle swarm -- R096. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@fips_kernel;
[xBest,fBest,history]=cbSolve('fips',fun,lb,ub,options);
end
