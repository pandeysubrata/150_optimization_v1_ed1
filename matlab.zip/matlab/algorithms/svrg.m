function [xBest,fBest,history]=svrg(fun,lb,ub,options)
% SVRG -- R071. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@svrg_kernel;
[xBest,fBest,history]=cbSolve('svrg',fun,lb,ub,options);
end
