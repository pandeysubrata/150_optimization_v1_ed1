function [xBest,fBest,history]=de_current_best(fun,lb,ub,options)
% DE/current-to-best/1/bin -- R083. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@de_current_best_kernel;
[xBest,fBest,history]=cbSolve('de_current_best',fun,lb,ub,options);
end
