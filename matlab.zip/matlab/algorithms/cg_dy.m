function [xBest,fBest,history]=cg_dy(fun,lb,ub,options)
% Dai-Yuan nonlinear CG -- R013. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cg_dy_kernel;
[xBest,fBest,history]=cbSolve('cg_dy',fun,lb,ub,options);
end
