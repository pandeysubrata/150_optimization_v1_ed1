function [xBest,fBest,history]=spea2(fun,lb,ub,options)
% SPEA2 -- R124. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@spea2_kernel;
[xBest,fBest,history]=cbSolve('spea2',fun,lb,ub,options);
end
