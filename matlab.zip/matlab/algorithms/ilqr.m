function [xBest,fBest,history]=ilqr(fun,lb,ub,options)
% Iterative LQR -- R139. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ilqr_kernel;
[xBest,fBest,history]=cbSolve('ilqr',fun,lb,ub,options);
end
