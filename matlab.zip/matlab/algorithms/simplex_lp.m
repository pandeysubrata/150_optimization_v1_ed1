function [xBest,fBest,history]=simplex_lp(fun,lb,ub,options)
% Primal simplex for LP -- R030. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@simplex_lp_kernel;
[xBest,fBest,history]=cbSolve('simplex_lp',fun,lb,ub,options);
end
