function [xBest,fBest,history]=rmsprop(fun,lb,ub,options)
% RMSprop -- R064. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@rmsprop_kernel;
[xBest,fBest,history]=cbSolve('rmsprop',fun,lb,ub,options);
end
