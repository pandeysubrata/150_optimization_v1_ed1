function [xBest,fBest,history]=proximal_gradient(fun,lb,ub,options)
% Proximal gradient / ISTA -- R020. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@proximal_gradient_kernel;
[xBest,fBest,history]=cbSolve('proximal_gradient',fun,lb,ub,options);
end
