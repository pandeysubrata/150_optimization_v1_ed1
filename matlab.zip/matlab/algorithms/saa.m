function [xBest,fBest,history]=saa(fun,lb,ub,options)
% Sample-average approximation -- R131. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@saa_kernel;
[xBest,fBest,history]=cbSolve('saa',fun,lb,ub,options);
end
