function [xBest,fBest,history]=gradient_descent(fun,lb,ub,options)
% Gradient descent -- R001. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@gradient_descent_kernel;
[xBest,fBest,history]=cbSolve('gradient_descent',fun,lb,ub,options);
end
