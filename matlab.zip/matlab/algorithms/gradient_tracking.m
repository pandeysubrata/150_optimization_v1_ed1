function [xBest,fBest,history]=gradient_tracking(fun,lb,ub,options)
% Distributed gradient tracking -- R138. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@gradient_tracking_kernel;
[xBest,fBest,history]=cbSolve('gradient_tracking',fun,lb,ub,options);
end
