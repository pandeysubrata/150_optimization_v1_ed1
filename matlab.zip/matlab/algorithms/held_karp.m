function [xBest,fBest,history]=held_karp(fun,lb,ub,options)
% Held-Karp TSP dynamic programming -- R036. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@held_karp_kernel;
[xBest,fBest,history]=cbSolve('held_karp',fun,lb,ub,options);
end
