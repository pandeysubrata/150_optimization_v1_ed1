function [xBest,fBest,history]=ant_system(fun,lb,ub,options)
% Ant System -- R099. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ant_system_kernel;
[xBest,fBest,history]=cbSolve('ant_system',fun,lb,ub,options);
end
