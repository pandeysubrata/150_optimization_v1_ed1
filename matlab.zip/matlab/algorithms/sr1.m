function [xBest,fBest,history]=sr1(fun,lb,ub,options)
% Symmetric rank-one quasi-Newton -- R009. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@sr1_kernel;
[xBest,fBest,history]=cbSolve('sr1',fun,lb,ub,options);
end
