function [xBest,fBest,history]=bfgs(fun,lb,ub,options)
% BFGS -- R006. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@bfgs_kernel;
[xBest,fBest,history]=cbSolve('bfgs',fun,lb,ub,options);
end
