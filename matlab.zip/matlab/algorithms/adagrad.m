function [xBest,fBest,history]=adagrad(fun,lb,ub,options)
% AdaGrad -- R063. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adagrad_kernel;
[xBest,fBest,history]=cbSolve('adagrad',fun,lb,ub,options);
end
