function [xBest,fBest,history]=knapsack_dp(fun,lb,ub,options)
% Knapsack dynamic programming -- R035. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@knapsack_dp_kernel;
[xBest,fBest,history]=cbSolve('knapsack_dp',fun,lb,ub,options);
end
