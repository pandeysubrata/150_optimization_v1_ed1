function [xBest,fBest,history]=jade(fun,lb,ub,options)
% JADE -- R141. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@jade_kernel;
[xBest,fBest,history]=cbSolve('jade',fun,lb,ub,options);
end
