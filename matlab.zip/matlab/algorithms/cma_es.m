function [xBest,fBest,history]=cma_es(fun,lb,ub,options)
% CMA-ES -- R087. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cma_es_kernel;
[xBest,fBest,history]=cbSolve('cma_es',fun,lb,ub,options);
end
