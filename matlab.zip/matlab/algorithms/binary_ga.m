function [xBest,fBest,history]=binary_ga(fun,lb,ub,options)
% Binary genetic algorithm -- R078. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@binary_ga_kernel;
[xBest,fBest,history]=cbSolve('binary_ga',fun,lb,ub,options);
end
