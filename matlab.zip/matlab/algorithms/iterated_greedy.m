function [xBest,fBest,history]=iterated_greedy(fun,lb,ub,options)
% Iterated greedy -- R120. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@iterated_greedy_kernel;
[xBest,fBest,history]=cbSolve('iterated_greedy',fun,lb,ub,options);
end
