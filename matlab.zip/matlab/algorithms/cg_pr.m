function [xBest,fBest,history]=cg_pr(fun,lb,ub,options)
% Polak-Ribiere-plus nonlinear CG -- R011. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cg_pr_kernel;
[xBest,fBest,history]=cbSolve('cg_pr',fun,lb,ub,options);
end
