function [xBest,fBest,history]=cg_fr(fun,lb,ub,options)
% Fletcher-Reeves nonlinear CG -- R010. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cg_fr_kernel;
[xBest,fBest,history]=cbSolve('cg_fr',fun,lb,ub,options);
end
