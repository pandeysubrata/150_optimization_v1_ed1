function [xBest,fBest,history]=memetic_ga(fun,lb,ub,options)
% Memetic genetic search -- R148. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@memetic_ga_kernel;
[xBest,fBest,history]=cbSolve('memetic_ga',fun,lb,ub,options);
end
