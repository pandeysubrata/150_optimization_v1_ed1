function [xBest,fBest,history]=pso(fun,lb,ub,options)
% Original particle swarm -- R092. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@pso_kernel;
[xBest,fBest,history]=cbSolve('pso',fun,lb,ub,options);
end
