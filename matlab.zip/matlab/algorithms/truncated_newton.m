function [xBest,fBest,history]=truncated_newton(fun,lb,ub,options)
% Truncated Newton-CG -- R018. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@truncated_newton_kernel;
[xBest,fBest,history]=cbSolve('truncated_newton',fun,lb,ub,options);
end
