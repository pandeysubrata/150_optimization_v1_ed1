function [xBest,fBest,history]=maxmin_ant(fun,lb,ub,options)
% MAX-MIN Ant System -- R101. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@maxmin_ant_kernel;
[xBest,fBest,history]=cbSolve('maxmin_ant',fun,lb,ub,options);
end
