function [xBest,fBest,history]=qpso(fun,lb,ub,options)
% Quantum-behaved PSO -- R098. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@qpso_kernel;
[xBest,fBest,history]=cbSolve('qpso',fun,lb,ub,options);
end
