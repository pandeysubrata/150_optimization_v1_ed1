function [xBest,fBest,history]=cobyla(fun,lb,ub,options)
% COBYLA -- R057. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cobyla_kernel;
[xBest,fBest,history]=cbSolve('cobyla',fun,lb,ub,options);
end
