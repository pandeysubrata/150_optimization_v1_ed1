function [xBest,fBest,history]=moead(fun,lb,ub,options)
% MOEA/D -- R125. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@moead_kernel;
[xBest,fBest,history]=cbSolve('moead',fun,lb,ub,options);
end
