function [xBest,fBest,history]=ils(fun,lb,ub,options)
% Iterated local search -- R115. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ils_kernel;
[xBest,fBest,history]=cbSolve('ils',fun,lb,ub,options);
end
