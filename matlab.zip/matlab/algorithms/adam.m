function [xBest,fBest,history]=adam(fun,lb,ub,options)
% Adam -- R066. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adam_kernel;
[xBest,fBest,history]=cbSolve('adam',fun,lb,ub,options);
end
