function [xBest,fBest,history]=ellipsoid(fun,lb,ub,options)
% Ellipsoid method -- R031. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ellipsoid_kernel;
[xBest,fBest,history]=cbSolve('ellipsoid',fun,lb,ub,options);
end
