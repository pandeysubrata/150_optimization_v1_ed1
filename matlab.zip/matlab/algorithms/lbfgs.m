function [xBest,fBest,history]=lbfgs(fun,lb,ub,options)
% Limited-memory BFGS -- R008. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@lbfgs_kernel;
[xBest,fBest,history]=cbSolve('lbfgs',fun,lb,ub,options);
end
