function [xBest,fBest,history]=fista(fun,lb,ub,options)
% FISTA -- R021. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@fista_kernel;
[xBest,fBest,history]=cbSolve('fista',fun,lb,ub,options);
end
