function [xBest,fBest,history]=away_frank_wolfe(fun,lb,ub,options)
% Away-step Frank-Wolfe -- R023. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@away_frank_wolfe_kernel;
[xBest,fBest,history]=cbSolve('away_frank_wolfe',fun,lb,ub,options);
end
