function [xBest,fBest,history]=shade(fun,lb,ub,options)
% SHADE -- R142. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@shade_kernel;
[xBest,fBest,history]=cbSolve('shade',fun,lb,ub,options);
end
