function [xBest,fBest,history]=consensus_admm(fun,lb,ub,options)
% Consensus ADMM -- R135. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@consensus_admm_kernel;
[xBest,fBest,history]=cbSolve('consensus_admm',fun,lb,ub,options);
end
