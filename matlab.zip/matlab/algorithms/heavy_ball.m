function [xBest,fBest,history]=heavy_ball(fun,lb,ub,options)
% Heavy-ball momentum -- R002. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@heavy_ball_kernel;
[xBest,fBest,history]=cbSolve('heavy_ball',fun,lb,ub,options);
end
