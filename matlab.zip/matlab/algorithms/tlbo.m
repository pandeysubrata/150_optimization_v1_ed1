function [xBest,fBest,history]=tlbo(fun,lb,ub,options)
% Teaching-learning-based optimization -- R107. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@tlbo_kernel;
[xBest,fBest,history]=cbSolve('tlbo',fun,lb,ub,options);
end
