function [xBest,fBest,history]=cuckoo(fun,lb,ub,options)
% Cuckoo search -- R104. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cuckoo_kernel;
[xBest,fBest,history]=cbSolve('cuckoo',fun,lb,ub,options);
end
