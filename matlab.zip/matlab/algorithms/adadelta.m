function [xBest,fBest,history]=adadelta(fun,lb,ub,options)
% AdaDelta -- R065. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adadelta_kernel;
[xBest,fBest,history]=cbSolve('adadelta',fun,lb,ub,options);
end
