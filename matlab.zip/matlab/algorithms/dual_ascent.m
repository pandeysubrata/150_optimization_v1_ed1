function [xBest,fBest,history]=dual_ascent(fun,lb,ub,options)
% Dual gradient ascent -- R025. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@dual_ascent_kernel;
[xBest,fBest,history]=cbSolve('dual_ascent',fun,lb,ub,options);
end
