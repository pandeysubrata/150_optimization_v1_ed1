function [xBest,fBest,history]=lshade(fun,lb,ub,options)
% L-SHADE -- R143. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@lshade_kernel;
[xBest,fBest,history]=cbSolve('lshade',fun,lb,ub,options);
end
