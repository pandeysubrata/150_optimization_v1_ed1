function [xBest,fBest,history]=threshold_accepting(fun,lb,ub,options)
% Threshold accepting -- R112. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@threshold_accepting_kernel;
[xBest,fBest,history]=cbSolve('threshold_accepting',fun,lb,ub,options);
end
