function [xBest,fBest,history]=nsga2(fun,lb,ub,options)
% NSGA-II -- R123. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@nsga2_kernel;
[xBest,fBest,history]=cbSolve('nsga2',fun,lb,ub,options);
end
