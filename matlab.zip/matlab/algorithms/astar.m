function [xBest,fBest,history]=astar(fun,lb,ub,options)
% A-star search -- R044. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@astar_kernel;
[xBest,fBest,history]=cbSolve('astar',fun,lb,ub,options);
end
