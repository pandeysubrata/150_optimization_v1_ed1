function [xBest,fBest,history]=damped_newton(fun,lb,ub,options)
% Damped Newton -- R005. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@damped_newton_kernel;
[xBest,fBest,history]=cbSolve('damped_newton',fun,lb,ub,options);
end
