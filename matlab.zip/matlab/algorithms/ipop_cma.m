function [xBest,fBest,history]=ipop_cma(fun,lb,ub,options)
% IPOP-CMA-ES -- R146. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ipop_cma_kernel;
[xBest,fBest,history]=cbSolve('ipop_cma',fun,lb,ub,options);
end
