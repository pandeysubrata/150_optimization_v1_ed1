function [xBest,fBest,history]=firefly(fun,lb,ub,options)
% Firefly algorithm -- R103. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@firefly_kernel;
[xBest,fBest,history]=cbSolve('firefly',fun,lb,ub,options);
end
