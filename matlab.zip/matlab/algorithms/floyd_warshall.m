function [xBest,fBest,history]=floyd_warshall(fun,lb,ub,options)
% Floyd-Warshall all-pairs paths -- R040. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@floyd_warshall_kernel;
[xBest,fBest,history]=cbSolve('floyd_warshall',fun,lb,ub,options);
end
