function [xBest,fBest,history]=dijkstra(fun,lb,ub,options)
% Dijkstra shortest path -- R038. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@dijkstra_kernel;
[xBest,fBest,history]=cbSolve('dijkstra',fun,lb,ub,options);
end
