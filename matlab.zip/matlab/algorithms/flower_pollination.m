function [xBest,fBest,history]=flower_pollination(fun,lb,ub,options)
% Flower pollination algorithm -- R108. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@flower_pollination_kernel;
[xBest,fBest,history]=cbSolve('flower_pollination',fun,lb,ub,options);
end
