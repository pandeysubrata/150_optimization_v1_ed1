function [xBest,fBest,history]=adafactor(fun,lb,ub,options)
% Adafactor -- R075. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adafactor_kernel;
[xBest,fBest,history]=cbSolve('adafactor',fun,lb,ub,options);
end
