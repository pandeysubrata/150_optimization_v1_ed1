function [xBest,fBest,history]=adamax(fun,lb,ub,options)
% AdaMax -- R068. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@adamax_kernel;
[xBest,fBest,history]=cbSolve('adamax',fun,lb,ub,options);
end
