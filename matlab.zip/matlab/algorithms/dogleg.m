function [xBest,fBest,history]=dogleg(fun,lb,ub,options)
% Dogleg trust region -- R015. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@dogleg_kernel;
[xBest,fBest,history]=cbSolve('dogleg',fun,lb,ub,options);
end
