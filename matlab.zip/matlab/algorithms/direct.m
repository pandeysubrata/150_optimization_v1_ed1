function [xBest,fBest,history]=direct(fun,lb,ub,options)
% DIRECT -- R056. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@direct_kernel;
[xBest,fBest,history]=cbSolve('direct',fun,lb,ub,options);
end
