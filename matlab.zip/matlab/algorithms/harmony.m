function [xBest,fBest,history]=harmony(fun,lb,ub,options)
% Harmony search -- R105. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@harmony_kernel;
[xBest,fBest,history]=cbSolve('harmony',fun,lb,ub,options);
end
