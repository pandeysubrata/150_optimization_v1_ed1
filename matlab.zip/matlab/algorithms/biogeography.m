function [xBest,fBest,history]=biogeography(fun,lb,ub,options)
% Biogeography-based optimization -- R109. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@biogeography_kernel;
[xBest,fBest,history]=cbSolve('biogeography',fun,lb,ub,options);
end
