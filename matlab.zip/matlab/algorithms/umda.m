function [xBest,fBest,history]=umda(fun,lb,ub,options)
% Univariate marginal distribution algorithm -- R088. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@umda_kernel;
[xBest,fBest,history]=cbSolve('umda',fun,lb,ub,options);
end
