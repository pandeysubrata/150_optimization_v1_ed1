function [xBest,fBest,history]=paes(fun,lb,ub,options)
% Pareto archived evolution strategy -- R127. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@paes_kernel;
[xBest,fBest,history]=cbSolve('paes',fun,lb,ub,options);
end
