function [xBest,fBest,history]=lookahead(fun,lb,ub,options)
% Lookahead -- R150. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@lookahead_kernel;
[xBest,fBest,history]=cbSolve('lookahead',fun,lb,ub,options);
end
