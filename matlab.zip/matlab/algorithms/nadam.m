function [xBest,fBest,history]=nadam(fun,lb,ub,options)
% Nadam -- R069. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@nadam_kernel;
[xBest,fBest,history]=cbSolve('nadam',fun,lb,ub,options);
end
