function [xBest,fBest,history]=brent(fun,lb,ub,options)
% Brent bounded scalar minimization -- R050. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@brent_kernel;
[xBest,fBest,history]=cbSolve('brent',fun,lb,ub,options);
end
