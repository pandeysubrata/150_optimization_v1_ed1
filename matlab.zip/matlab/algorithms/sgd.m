function [xBest,fBest,history]=sgd(fun,lb,ub,options)
% Stochastic gradient descent -- R061. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@sgd_kernel;
[xBest,fBest,history]=cbSolve('sgd',fun,lb,ub,options);
end
