function [xBest,fBest,history]=ring_pso(fun,lb,ub,options)
% Local-best ring PSO -- R095. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@ring_pso_kernel;
[xBest,fBest,history]=cbSolve('ring_pso',fun,lb,ub,options);
end
