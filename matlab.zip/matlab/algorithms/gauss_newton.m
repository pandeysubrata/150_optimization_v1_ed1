function [xBest,fBest,history]=gauss_newton(fun,lb,ub,options)
% Gauss-Newton least squares -- R017. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@gauss_newton_kernel;
[xBest,fBest,history]=cbSolve('gauss_newton',fun,lb,ub,options);
end
