function [xBest,fBest,history]=sade(fun,lb,ub,options)
% SaDE -- R145. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@sade_kernel;
[xBest,fBest,history]=cbSolve('sade',fun,lb,ub,options);
end
