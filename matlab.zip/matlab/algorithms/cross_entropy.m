function [xBest,fBest,history]=cross_entropy(fun,lb,ub,options)
% Cross-entropy search -- R091. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cross_entropy_kernel;
[xBest,fBest,history]=cbSolve('cross_entropy',fun,lb,ub,options);
end
