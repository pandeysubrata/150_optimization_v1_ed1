function [xBest,fBest,history]=amsgrad(fun,lb,ub,options)
% AMSGrad -- R070. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@amsgrad_kernel;
[xBest,fBest,history]=cbSolve('amsgrad',fun,lb,ub,options);
end
