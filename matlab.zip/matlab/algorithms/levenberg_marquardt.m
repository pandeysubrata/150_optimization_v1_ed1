function [xBest,fBest,history]=levenberg_marquardt(fun,lb,ub,options)
% Levenberg-Marquardt -- R014. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@levenberg_marquardt_kernel;
[xBest,fBest,history]=cbSolve('levenberg_marquardt',fun,lb,ub,options);
end
