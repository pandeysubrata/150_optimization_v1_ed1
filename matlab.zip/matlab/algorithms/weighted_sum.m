function [xBest,fBest,history]=weighted_sum(fun,lb,ub,options)
% Weighted-sum scalarization -- R121. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@weighted_sum_kernel;
[xBest,fBest,history]=cbSolve('weighted_sum',fun,lb,ub,options);
end
