function [xBest,fBest,history]=basin_hopping(fun,lb,ub,options)
% Basin hopping -- R149. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@basin_hopping_kernel;
[xBest,fBest,history]=cbSolve('basin_hopping',fun,lb,ub,options);
end
