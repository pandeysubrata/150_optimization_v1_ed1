function [xBest,fBest,history]=es_one(fun,lb,ub,options)
% One-plus-one evolution strategy -- R084. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@es_one_kernel;
[xBest,fBest,history]=cbSolve('es_one',fun,lb,ub,options);
end
