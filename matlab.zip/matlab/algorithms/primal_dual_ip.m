function [xBest,fBest,history]=primal_dual_ip(fun,lb,ub,options)
% Primal-dual interior point -- R029. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@primal_dual_ip_kernel;
[xBest,fBest,history]=cbSolve('primal_dual_ip',fun,lb,ub,options);
end
