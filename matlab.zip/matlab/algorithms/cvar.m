function [xBest,fBest,history]=cvar(fun,lb,ub,options)
% CVaR optimization -- R133. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cvar_kernel;
[xBest,fBest,history]=cbSolve('cvar',fun,lb,ub,options);
end
