function [xBest,fBest,history]=cg_hs(fun,lb,ub,options)
% Hestenes-Stiefel nonlinear CG -- R012. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@cg_hs_kernel;
[xBest,fBest,history]=cbSolve('cg_hs',fun,lb,ub,options);
end
