function [xBest,fBest,history]=record_to_record(fun,lb,ub,options)
% Record-to-record travel -- R113. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@record_to_record_kernel;
[xBest,fBest,history]=cbSolve('record_to_record',fun,lb,ub,options);
end
