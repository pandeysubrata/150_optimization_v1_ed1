function [xBest,fBest,history]=de_best2(fun,lb,ub,options)
% DE/best/2/bin -- R082. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@de_best2_kernel;
[xBest,fBest,history]=cbSolve('de_best2',fun,lb,ub,options);
end
