function [xBest,fBest,history]=prim(fun,lb,ub,options)
% Prim minimum spanning tree -- R041. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@prim_kernel;
[xBest,fBest,history]=cbSolve('prim',fun,lb,ub,options);
end
