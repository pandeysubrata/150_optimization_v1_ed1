function [xBest,fBest,history]=chambolle_pock(fun,lb,ub,options)
% Chambolle-Pock primal-dual -- R033. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@chambolle_pock_kernel;
[xBest,fBest,history]=cbSolve('chambolle_pock',fun,lb,ub,options);
end
