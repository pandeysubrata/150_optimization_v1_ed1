function [xBest,fBest,history]=de_rand2(fun,lb,ub,options)
% DE/rand/2/bin -- R081. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@de_rand2_kernel;
[xBest,fBest,history]=cbSolve('de_rand2',fun,lb,ub,options);
end
