function [xBest,fBest,history]=spsa(fun,lb,ub,options)
% Simultaneous perturbation stochastic approximation -- R060. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@spsa_kernel;
[xBest,fBest,history]=cbSolve('spsa',fun,lb,ub,options);
end
