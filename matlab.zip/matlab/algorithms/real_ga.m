function [xBest,fBest,history]=real_ga(fun,lb,ub,options)
% Real-coded genetic algorithm -- R077. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@real_ga_kernel;
[xBest,fBest,history]=cbSolve('real_ga',fun,lb,ub,options);
end
