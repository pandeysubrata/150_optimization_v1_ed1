function [xBest,fBest,history]=bipop_cma(fun,lb,ub,options)
% BIPOP-CMA-ES -- R147. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@bipop_cma_kernel;
[xBest,fBest,history]=cbSolve('bipop_cma',fun,lb,ub,options);
end
