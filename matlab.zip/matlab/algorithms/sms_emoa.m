function [xBest,fBest,history]=sms_emoa(fun,lb,ub,options)
% SMS-EMOA -- R130. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.multi=true;
options.kernel=@sms_emoa_kernel;
[xBest,fBest,history]=cbSolve('sms_emoa',fun,lb,ub,options);
end
