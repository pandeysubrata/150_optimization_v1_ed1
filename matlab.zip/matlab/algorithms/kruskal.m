function [xBest,fBest,history]=kruskal(fun,lb,ub,options)
% Kruskal minimum spanning tree -- R042. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@kruskal_kernel;
[xBest,fBest,history]=cbSolve('kruskal',fun,lb,ub,options);
end
