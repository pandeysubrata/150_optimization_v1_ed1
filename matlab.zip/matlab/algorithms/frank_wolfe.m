function [xBest,fBest,history]=frank_wolfe(fun,lb,ub,options)
% Frank-Wolfe -- R022. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@frank_wolfe_kernel;
[xBest,fBest,history]=cbSolve('frank_wolfe',fun,lb,ub,options);
end
