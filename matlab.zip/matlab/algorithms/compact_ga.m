function [xBest,fBest,history]=compact_ga(fun,lb,ub,options)
% Compact genetic algorithm -- R090. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@compact_ga_kernel;
[xBest,fBest,history]=cbSolve('compact_ga',fun,lb,ub,options);
end
