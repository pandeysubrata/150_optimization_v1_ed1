function [xBest,fBest,history]=hungarian(fun,lb,ub,options)
% Hungarian assignment algorithm -- R037. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@hungarian_kernel;
[xBest,fBest,history]=cbSolve('hungarian',fun,lb,ub,options);
end
