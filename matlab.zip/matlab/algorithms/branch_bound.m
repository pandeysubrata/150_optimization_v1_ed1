function [xBest,fBest,history]=branch_bound(fun,lb,ub,options)
% Branch and bound for binary knapsack -- R034. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@branch_bound_kernel;
[xBest,fBest,history]=cbSolve('branch_bound',fun,lb,ub,options);
end
