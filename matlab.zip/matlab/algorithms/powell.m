function [xBest,fBest,history]=powell(fun,lb,ub,options)
% Powell direction-set method -- R052. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@powell_kernel;
[xBest,fBest,history]=cbSolve('powell',fun,lb,ub,options);
end
