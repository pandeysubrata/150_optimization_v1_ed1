function [xBest,fBest,history]=nesterov(fun,lb,ub,options)
% Nesterov accelerated gradient -- R003. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@nesterov_kernel;
[xBest,fBest,history]=cbSolve('nesterov',fun,lb,ub,options);
end
