function [xBest,fBest,history]=mads(fun,lb,ub,options)
% Mesh adaptive direct search -- R055. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@mads_kernel;
[xBest,fBest,history]=cbSolve('mads',fun,lb,ub,options);
end
