function [xBest,fBest,history]=vns(fun,lb,ub,options)
% Variable neighborhood search -- R116. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@vns_kernel;
[xBest,fBest,history]=cbSolve('vns',fun,lb,ub,options);
end
