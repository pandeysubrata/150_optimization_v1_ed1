function [xBest,fBest,history]=two_opt(fun,lb,ub,options)
% 2-opt tour improvement -- R045. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@two_opt_kernel;
[xBest,fBest,history]=cbSolve('two_opt',fun,lb,ub,options);
end
