function [xBest,fBest,history]=es_plus(fun,lb,ub,options)
% Mu-plus-lambda evolution strategy -- R085. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@es_plus_kernel;
[xBest,fBest,history]=cbSolve('es_plus',fun,lb,ub,options);
end
