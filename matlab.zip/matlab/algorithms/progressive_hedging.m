function [xBest,fBest,history]=progressive_hedging(fun,lb,ub,options)
% Progressive hedging -- R134. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@progressive_hedging_kernel;
[xBest,fBest,history]=cbSolve('progressive_hedging',fun,lb,ub,options);
end
