function [xBest,fBest,history]=farthest_insertion(fun,lb,ub,options)
% Farthest-insertion TSP heuristic -- R046. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@farthest_insertion_kernel;
[xBest,fBest,history]=cbSolve('farthest_insertion',fun,lb,ub,options);
end
