function [xBest,fBest,history]=mirror_descent(fun,lb,ub,options)
% Entropic mirror descent -- R032. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@mirror_descent_kernel;
[xBest,fBest,history]=cbSolve('mirror_descent',fun,lb,ub,options);
end
