function [xBest,fBest,history]=grasp(fun,lb,ub,options)
% GRASP -- R117. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@grasp_kernel;
[xBest,fBest,history]=cbSolve('grasp',fun,lb,ub,options);
end
