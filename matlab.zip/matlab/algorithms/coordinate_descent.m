function [xBest,fBest,history]=coordinate_descent(fun,lb,ub,options)
% Cyclic coordinate descent -- R016. See the printed kernel and scope.
if nargin<4, options=struct(); end
options.kernel=@coordinate_descent_kernel;
[xBest,fBest,history]=cbSolve('coordinate_descent',fun,lb,ub,options);
end
